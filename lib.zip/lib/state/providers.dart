import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../data/models/folder.dart';
import '../data/models/image_data.dart';
import '../data/models/report_data.dart';
import '../data/models/camera_settings.dart';
import '../data/models/annotation.dart';
import '../data/models/stored_calibration.dart';
import '../data/services/storage_service.dart';
import '../config/constants.dart';
import 'microscope_calibration_provider.dart';

final sharedPreferencesProvider = Provider<SharedPreferences>((ref) => throw UnimplementedError());

final storageServiceProvider = Provider<StorageService>((ref) => StorageService(ref.watch(sharedPreferencesProvider)));

final foldersProvider = StateNotifierProvider<FoldersNotifier, List<Folder>>((ref) => FoldersNotifier(ref.watch(storageServiceProvider)));

class FoldersNotifier extends StateNotifier<List<Folder>> {
  final StorageService _storage;
  FoldersNotifier(this._storage) : super([]) { _load(); }

  void _load() {
    final data = _storage.get<List<dynamic>>(AppConstants.keyFolders);
    if (data != null) state = data.map((f) => Folder.fromJson(Map<String, dynamic>.from(f))).toList();
  }

  void createFolder(String name) {
    state = [...state, Folder(id: DateTime.now().millisecondsSinceEpoch.toString(), name: name, createdAt: DateTime.now().toIso8601String(), images: [])];
    _save();
  }

  void deleteFolder(String id) { state = state.where((f) => f.id != id).toList(); _save(); }

  void renameFolder(String id, String newName) {
    state = state.map((f) => f.id == id ? f.copyWith(name: newName) : f).toList(); _save();
  }

  void addImage(String folderId, ImageData image) {
    state = state.map((f) { if (f.id != folderId) return f; return f.copyWith(images: [...f.images, image]); }).toList(); _save();
  }

  void removeImage(String folderId, String imageId) {
    state = state.map((f) { if (f.id != folderId) return f; return f.copyWith(images: f.images.where((i) => i.id != imageId).toList()); }).toList(); _save();
  }

  void removeImages(String folderId, Set<String> imageIds) {
    state = state.map((f) { if (f.id != folderId) return f; return f.copyWith(images: f.images.where((i) => !imageIds.contains(i.id)).toList()); }).toList(); _save();
  }

  void updateImage(String folderId, String imageId, ImageData updated) {
    state = state.map((f) { if (f.id != folderId) return f; return f.copyWith(images: f.images.map((i) => i.id == imageId ? updated : i).toList()); }).toList(); _save();
  }

  void addReport(String folderId, ReportData report) {
    state = state.map((folder) {
      if (folder.id != folderId) return folder;
      return folder.copyWith(reports: [...?folder.reports, report]);
    }).toList();
    _save();
  }

  Future<void> clearAll() async {
    state = [];
    await _storage.remove(AppConstants.keyFolders);
  }

  void _save() { _storage.set(AppConstants.keyFolders, state.map((f) => f.toJson()).toList()); }
}

final selectedToolProvider = StateProvider<AnnotationType?>((ref) => null);
final drawingColorProvider = StateProvider<Color>((ref) => const Color(0xFFFF00FF));
final measurementModeProvider = StateProvider<bool>((ref) => false);

final calibrationProvider = StateNotifierProvider<CalibrationNotifier, Map<String, StoredCalibration>>((ref) => CalibrationNotifier(ref.watch(sharedPreferencesProvider)));

class CalibrationNotifier extends StateNotifier<Map<String, StoredCalibration>> {
  final SharedPreferences _prefs;
  CalibrationNotifier(this._prefs) : super({}) { _load(); }

  void _load() {
    final raw = _prefs.getString(AppConstants.keyCalibrations);
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      state = decoded.map(
        (k, v) => MapEntry(
          k,
          StoredCalibration.fromJson(Map<String, dynamic>.from(v as Map)),
        ),
      );
    } catch (_) {}
  }

  void saveCalibration(StoredCalibration cal) {
    state = {...state, cal.lens: cal};
    _save();
  }

  StoredCalibration? getForLens(String lens) => state[lens];

  Future<void> clearAll() async {
    state = {};
    await _prefs.remove(AppConstants.keyCalibrations);
  }

  void _save() {
    final map = state.map((k, v) => MapEntry(k, v.toJson()));
    _prefs.setString(AppConstants.keyCalibrations, jsonEncode(map));
  }
}

final cameraSettingsProvider = StateProvider<CameraSettings>((ref) => const CameraSettings());

final microscopeCalibrationProvider =
    ChangeNotifierProvider<MicroscopeCalibrationProvider>((ref) {
  return MicroscopeCalibrationProvider(ref.watch(sharedPreferencesProvider));
});
