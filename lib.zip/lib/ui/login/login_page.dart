// lib/pages/login_page.dart (Updated)
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../config/auth_service.dart';
import '../common/brand_logo.dart';
import '../../config/theme.dart';
import '../../config/constants.dart';
import '../../utils/responsive.dart';
import '../common/hexa_toast.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _authService = AuthService();

  bool _showPassword = false;
  bool _isLoading = false;
  String? _connectionStatus;
  String? _lastLoginInfo;

  late AnimationController _glowController;
  late List<_Particle> _particles;
  final _random = Random();

  @override
  void initState() {
    super.initState();
    _checkConnection();
    _loadLastLoginInfo();
    _checkAutoLogin();

    _glowController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _particles = List.generate(
      8,
          (_) => _Particle(
        x: _random.nextDouble(),
        y: _random.nextDouble(),
        controller: AnimationController(
          duration: Duration(milliseconds: 4000 + _random.nextInt(2000)),
          vsync: this,
        )..repeat(reverse: true),
      ),
    );
  }

  Future<void> _checkConnection() async {
    bool isConnected = await _authService.hasInternetConnection();
    setState(() {
      _connectionStatus = isConnected ? 'Online' : 'Offline';
    });
  }

  Future<void> _loadLastLoginInfo() async {
    var lastLogin = await _authService.getLastLoginInfo();
    if (lastLogin != null && mounted) {
      DateTime loginTime = DateTime.parse(lastLogin['last_login']);
      String formattedTime = '${loginTime.day}/${loginTime.month}/${loginTime.year} ${loginTime.hour}:${loginTime.minute}';
      setState(() {
        _lastLoginInfo = 'Last login: $formattedTime (${lastLogin['login_type']})';
      });
    }
  }

  Future<void> _checkAutoLogin() async {
    bool isLoggedIn = await _authService.isLoggedIn();
    if (isLoggedIn && mounted) {
      context.go('/folders');
    }
  }

  @override
  void dispose() {
    _glowController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    for (final p in _particles) {
      p.controller.dispose();
    }
    super.dispose();
  }

  Future<void> _handleLogin() async {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      HexaToast.show(
        context,
        'Please enter both email and password',
        type: HexaToastType.error,
      );
      return;
    }

    setState(() => _isLoading = true);

    LoginResult result = await _authService.login(
      _emailController.text.trim(),
      _passwordController.text,
    );

    setState(() => _isLoading = false);

    if (result.isSuccess) {
      HexaToast.show(
        context,
        result.isOffline
            ? 'Welcome back! (Offline Mode)'
            : 'Welcome to Hexa-Cam!',
        type: HexaToastType.success,
      );
      context.go('/folders');
    } else {
      HexaToast.show(
        context,
        result.message,
        type: HexaToastType.error,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isTab = Responsive.isTablet(context);
    const cardMaxWidth = 420.0;
    final cardPadding = isTab ? 30.0 : 22.0;
    final fieldFontSize = isTab ? 15.0 : 13.0;
    final btnHeight = Responsive.buttonHeight(context);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.bgPrimary,
              AppTheme.bgSecondary,
              AppTheme.bgTertiary
            ],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(
          children: [
            // Animated particles background
            ..._particles.map((p) => AnimatedBuilder(
              animation: p.controller,
              builder: (_, __) => Positioned(
                left: MediaQuery.sizeOf(context).width * p.x,
                top: MediaQuery.sizeOf(context).height * p.y,
                child: Opacity(
                  opacity: 0.2 + p.controller.value * 0.3,
                  child: Container(
                    width: isTab ? 6 : 4,
                    height: isTab ? 6 : 4,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.primary,
                    ),
                  ),
                ),
              ),
            )),

            // Main content
            Center(
              child: SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: MediaQuery.sizeOf(context).height,
                  ),
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: Responsive.pagePadding(context),
                      vertical: isTab ? 40 : 24,
                    ),
                    child: Center(
                      child: Container(
                        constraints: const BoxConstraints(maxWidth: cardMaxWidth),
                        padding: EdgeInsets.all(cardPadding),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(28),
                          border: Border.all(color: const Color(0x336C7DFF)),
                          gradient: const LinearGradient(
                            colors: [Color(0xF21A1F4A), Color(0xF213173B)],
                          ),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x88202560),
                              blurRadius: 36,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Column(
                          children: [
                            // Connection Status Badge
                            Container(
                              margin: const EdgeInsets.only(bottom: 16),
                              padding: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: _connectionStatus == 'Online'
                                    ? Colors.green.withOpacity(0.2)
                                    : Colors.orange.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: _connectionStatus == 'Online'
                                      ? Colors.green
                                      : Colors.orange,
                                  width: 1,
                                ),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    _connectionStatus == 'Online'
                                        ? Icons.wifi
                                        : Icons.signal_wifi_off,
                                    size: 14,
                                    color: _connectionStatus == 'Online'
                                        ? Colors.green
                                        : Colors.orange,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    _connectionStatus == 'Online'
                                        ? 'Online Mode'
                                        : 'Offline Mode',
                                    style: TextStyle(
                                      color: _connectionStatus == 'Online'
                                          ? Colors.green
                                          : Colors.orange,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Logo
                            Center(
                              child: Column(
                                children: [
                                  Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Image.asset('assets/images/app_logo.png'),
                                      Positioned(
                                        bottom: 2,
                                        child: const Column(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Text(
                                              "Hexa-Cam",
                                              style: TextStyle(
                                                fontSize: 18,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                              ),
                                            ),
                                            Text(
                                              "Scientific Imaging & Microscopy",
                                              style: TextStyle(
                                                color: Colors.white60,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 16),

                            // Last login info
                            if (_lastLoginInfo != null)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 4,
                                ),
                                decoration: BoxDecoration(
                                  color: AppTheme.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  _lastLoginInfo!,
                                  style: TextStyle(
                                    color: AppTheme.primary,
                                    fontSize: 10,
                                  ),
                                ),
                              ),

                            SizedBox(height: isTab ? 40 : 32),

                            // Email field
                            _buildLabel('Email Address'),
                            const SizedBox(height: 8),
                            _buildTextField(
                              _emailController,
                              'Enter your email',
                              Icons.mail_outline,
                              fontSize: fieldFontSize,
                            ),
                            SizedBox(height: isTab ? 24 : 20),

                            // Password field
                            _buildLabel('Password'),
                            const SizedBox(height: 8),
                            _buildTextField(
                              _passwordController,
                              'Enter your password',
                              Icons.lock_outline,
                              isPassword: true,
                              fontSize: fieldFontSize,
                            ),
                            const SizedBox(height: 8),

                            const SizedBox(height: 8),

                            // Sign In button
                            SizedBox(
                              width: double.infinity,
                              height: btnHeight,
                              child: ElevatedButton(
                                onPressed: _isLoading ? null : _handleLogin,
                                style: ElevatedButton.styleFrom(
                                  padding: EdgeInsets.zero,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  backgroundColor: Colors.transparent,
                                ),
                                child: Ink(
                                  decoration: BoxDecoration(
                                    gradient: AppTheme.primaryGradient,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Center(
                                    child: _isLoading
                                        ? const SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white,
                                      ),
                                    )
                                        : Text(
                                      'Sign In',
                                      style: TextStyle(
                                        fontSize: isTab ? 16 : 14,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(height: isTab ? 24 : 20),

                            // Divider
                            const Row(children: [
                              Expanded(child: Divider(color: AppTheme.borderColor)),
                              Padding(
                                padding: EdgeInsets.symmetric(horizontal: 12),
                                child: Text(
                                  'OR CONTINUE WITH',
                                  style: TextStyle(
                                    color: AppTheme.textMuted,
                                    fontSize: 10,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                              Expanded(child: Divider(color: AppTheme.borderColor)),
                            ]),
                            SizedBox(height: isTab ? 24 : 20),

                            // Demo Account button
                            SizedBox(
                              width: double.infinity,
                              height: btnHeight,
                              child: OutlinedButton(
                                onPressed: () {
                                  _emailController.text = 'demo@hexacam.com';
                                  _passwordController.text = 'demo123';
                                  HexaToast.show(
                                    context,
                                    'Demo credentials filled',
                                    type: HexaToastType.info,
                                  );
                                },
                                style: OutlinedButton.styleFrom(
                                  side: const BorderSide(color: AppTheme.borderColor),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  backgroundColor: AppTheme.bgTertiary,
                                ),
                                child: Text(
                                  'Use Demo Account',
                                  style: TextStyle(
                                    color: AppTheme.textSecondary,
                                    fontWeight: FontWeight.w600,
                                    fontSize: isTab ? 16 : 14,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 16),

                            // Offline info text
                            if (_connectionStatus == 'Offline')
                              Container(
                                padding: const EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  color: Colors.orange.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  children: [
                                    Icon(Icons.info_outline, size: 14, color: Colors.orange),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        'Offline Mode: Using saved credentials',
                                        style: TextStyle(
                                          color: Colors.orange,
                                          fontSize: 11,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLabel(String text) {
    final isTab = Responsive.isTablet(context);
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        text,
        style: TextStyle(
          color: AppTheme.textSecondary,
          fontSize: isTab ? 15 : 14,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller,
      String hint,
      IconData icon, {
        bool isPassword = false,
        double fontSize = 16,
      }) {
    final isTab = Responsive.isTablet(context);
    return TextField(
      controller: controller,
      obscureText: isPassword && !_showPassword,
      style: TextStyle(color: AppTheme.textPrimary, fontSize: fontSize),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppTheme.textMuted),
        prefixIcon: Icon(icon, color: AppTheme.textMuted, size: isTab ? 22 : 20),
        suffixIcon: isPassword
            ? IconButton(
          onPressed: () => setState(() => _showPassword = !_showPassword),
          icon: Icon(
            _showPassword ? Icons.visibility_off : Icons.visibility,
            color: AppTheme.textMuted,
            size: isTab ? 22 : 20,
          ),
        )
            : null,
        filled: true,
        fillColor: AppTheme.bgTertiary,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.borderColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.borderColor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.primary),
        ),
        contentPadding: EdgeInsets.symmetric(
          horizontal: 16,
          vertical: isTab ? 16 : 14,
        ),
      ),
    );
  }
}

class _Particle {
  final double x;
  final double y;
  final AnimationController controller;
  _Particle({required this.x, required this.y, required this.controller});
}