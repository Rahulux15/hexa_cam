import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../state/providers.dart';

class CalibrationExampleWidget extends ConsumerStatefulWidget {
  const CalibrationExampleWidget({super.key});

  @override
  ConsumerState<CalibrationExampleWidget> createState() =>
      _CalibrationExampleWidgetState();
}

class _CalibrationExampleWidgetState
    extends ConsumerState<CalibrationExampleWidget> {
  String _magnification = '20X';
  String _unit = 'μm';

  final _knownDistanceController = TextEditingController(text: '100');
  final _measuredPixelsController = TextEditingController(text: '400');
  final _measuredDivisionsController = TextEditingController(text: '10');
  final _pixelsToMeasureController = TextEditingController(text: '160');
  final _divisionsToMeasureController = TextEditingController(text: '3.5');

  @override
  void dispose() {
    _knownDistanceController.dispose();
    _measuredPixelsController.dispose();
    _measuredDivisionsController.dispose();
    _pixelsToMeasureController.dispose();
    _divisionsToMeasureController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final calibration = ref
        .watch(microscopeCalibrationProvider)
        .getCalibrationForMagnification(_magnification);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            DropdownButton<String>(
              value: _magnification,
              items: const ['4X', '10X', '20X', '40X', '100X']
                  .map((value) => DropdownMenuItem(
                        value: value,
                        child: Text(value),
                      ))
                  .toList(),
              onChanged: (value) {
                if (value == null) return;
                setState(() => _magnification = value);
              },
            ),
            DropdownButton<String>(
              value: _unit,
              items: const ['μm', 'nm']
                  .map((value) => DropdownMenuItem(
                        value: value,
                        child: Text(value),
                      ))
                  .toList(),
              onChanged: (value) {
                if (value == null) return;
                setState(() => _unit = value);
              },
            ),
          ],
        ),
        const SizedBox(height: 12),
        _field(_knownDistanceController, 'Known Distance'),
        _field(_measuredPixelsController, 'Measured Pixels'),
        _field(_measuredDivisionsController, 'Measured Divisions (optional)'),
        const SizedBox(height: 10),
        ElevatedButton(
          onPressed: _saveCalibration,
          child: const Text('Set Calibration From Pixels'),
        ),
        const SizedBox(height: 12),
        Text(calibration == null
            ? 'Uncalibrated for $_magnification'
            : 'Calibrated: ${calibration.unitPerPixel.toStringAsFixed(4)} ${calibration.unit}/px'),
        const Divider(height: 24),
        _field(_pixelsToMeasureController, 'Pixels To Measure'),
        ElevatedButton(
          onPressed: _measurePixels,
          child: const Text('Measure Pixels'),
        ),
        const SizedBox(height: 10),
        _field(_divisionsToMeasureController, 'Observed Divisions'),
        ElevatedButton(
          onPressed: _measureDivisions,
          child: const Text('Measure Divisions'),
        ),
      ],
    );
  }

  Widget _field(TextEditingController controller, String label) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  void _saveCalibration() {
    final knownDistance = double.tryParse(_knownDistanceController.text) ?? 0;
    final measuredPixels = double.tryParse(_measuredPixelsController.text) ?? 0;
    final measuredDivisions = double.tryParse(_measuredDivisionsController.text);
    try {
      ref.read(microscopeCalibrationProvider).setCalibrationFromPixels(
            magnification: _magnification,
            knownDistance: knownDistance,
            measuredPixels: measuredPixels,
            measuredDivisions: measuredDivisions,
            unit: _unit,
          );
      _show('Calibration saved for $_magnification');
    } catch (error) {
      _show(error.toString(), isError: true);
    }
  }

  void _measurePixels() {
    final pixels = double.tryParse(_pixelsToMeasureController.text) ?? 0;
    final result = ref.read(microscopeCalibrationProvider).measurePixels(
          magnification: _magnification,
          pixels: pixels,
          unit: _unit,
        );
    if (result == null) {
      _show('Calibration missing for $_magnification', isError: true);
      return;
    }
    _show('Measured: ${result.formatted}');
  }

  void _measureDivisions() {
    final divisions = double.tryParse(_divisionsToMeasureController.text) ?? 0;
    final result = ref.read(microscopeCalibrationProvider).measureDivisions(
          magnification: _magnification,
          observedDivisions: divisions,
        );
    if (result == null) {
      _show('Division calibration missing for $_magnification', isError: true);
      return;
    }
    _show('Measured: ${result.formatted}');
  }

  void _show(String text, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }
}
