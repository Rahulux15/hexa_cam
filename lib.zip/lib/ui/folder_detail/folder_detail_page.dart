import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:printing/printing.dart';
import '../../config/theme.dart';
import '../../data/models/folder.dart';
import '../../data/models/image_data.dart';
import '../../data/models/report_data.dart';
import '../../data/services/database_service.dart';
import '../../state/providers.dart';
import '../../utils/responsive.dart';
import '../common/media_image.dart';

class FolderDetailPage extends ConsumerStatefulWidget {
  final String folderId;
  const FolderDetailPage({super.key, required this.folderId});
  @override
  ConsumerState<FolderDetailPage> createState() => _FolderDetailPageState();
}

class _FolderDetailPageState extends ConsumerState<FolderDetailPage> {
  bool _selectionMode = false;
  bool _gridView = true;
  final Set<String> _selectedImages = {};
  Timer? _longPressTimer;

  Folder? _getFolder(List<Folder> folders) {
    try {
      return folders.firstWhere((folder) => folder.id == widget.folderId);
    } catch (_) {
      return null;
    }
  }

  @override
  void dispose() {
    _longPressTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final folders = ref.watch(foldersProvider);
    final folder = _getFolder(folders);
    if (folder == null) {
      WidgetsBinding.instance
          .addPostFrameCallback((_) => context.go('/folders'));
      return const SizedBox();
    }

    final photos =
        folder.images.where((image) => image.type != MediaType.video).toList();
    final videos =
        folder.images.where((image) => image.type == MediaType.video).toList();
    final isTab = Responsive.isTablet(context);
    final pad = Responsive.pagePadding(context);
    final width = MediaQuery.sizeOf(context).width;
    final contentMaxWidth = width >= 1200 ? 1240.0 : 1120.0;

    return Scaffold(
      body: Container(
        color: AppTheme.bgPrimary,
        child: Column(children: [
          SafeArea(
            bottom: false,
            child: Container(
              padding: EdgeInsets.fromLTRB(pad, 18, pad, 16),
              decoration: const BoxDecoration(
                  color: Color(0xFF141430),
                  border:
                      Border(bottom: BorderSide(color: AppTheme.borderColor))),
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: contentMaxWidth),
                  child: Row(children: [
                    _roundButton(
                        icon: Icons.arrow_back_rounded,
                        onTap: () => context.pop(),
                        isTab: isTab),
                    SizedBox(width: isTab ? 20 : 14),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(folder.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: isTab ? 28 : 22,
                                    fontWeight: FontWeight.w800)),
                            const SizedBox(height: 6),
                            Wrap(spacing: 18, runSpacing: 6, children: [
                              _headerStat(Icons.image_outlined,
                                  '${photos.length} photos'),
                              _headerStat(Icons.videocam_outlined,
                                  '${videos.length} videos'),
                            ]),
                          ]),
                    ),
                    _roundButton(
                        icon: _selectionMode
                            ? Icons.check_box_outlined
                            : Icons.checklist_rounded,
                        onTap: () =>
                            setState(() => _selectionMode = !_selectionMode),
                        isTab: isTab,
                        active: _selectionMode),
                    SizedBox(width: isTab ? 12 : 8),
                    _roundButton(
                        icon: _gridView
                            ? Icons.view_list_rounded
                            : Icons.grid_view_rounded,
                        onTap: () => setState(() => _gridView = !_gridView),
                        isTab: isTab),
                  ]),
                ),
              ),
            ),
          ),
          if (_selectedImages.isNotEmpty)
            Padding(
              padding: EdgeInsets.fromLTRB(pad, 14, pad, 0),
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: contentMaxWidth),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: AppTheme.softCardDecoration(
                        borderRadius: BorderRadius.circular(18)),
                    child: Row(children: [
                      Text('${_selectedImages.length} selected',
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700)),
                      const Spacer(),
                      _selectionChip(
                          'Report', AppTheme.primary, _generateReport),
                      const SizedBox(width: 8),
                      _selectionChip(
                          'Delete', AppTheme.danger, _deleteSelected),
                      const SizedBox(width: 8),
                      _selectionChip(
                          'Cancel',
                          AppTheme.textMuted,
                          () => setState(() {
                                _selectedImages.clear();
                                _selectionMode = false;
                              })),
                    ]),
                  ),
                ),
              ),
            ),
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(pad, 24, pad, 28),
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: contentMaxWidth),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (folder.images.isEmpty)
                          Container(
                            height: isTab ? 320 : 240,
                            width: double.infinity,
                            decoration: AppTheme.softCardDecoration(
                                borderRadius: BorderRadius.circular(22)),
                            child: Center(
                                child: Text('No media yet',
                                    style: TextStyle(
                                        color: AppTheme.textMuted,
                                        fontSize: isTab ? 18 : 16))),
                          )
                        else if (_gridView)
                          Wrap(
                            spacing: isTab ? 22 : 16,
                            runSpacing: isTab ? 22 : 16,
                            children: folder.images
                                .map((image) => _buildMediaCard(image, width))
                                .toList(),
                          )
                        else
                          ...folder.images.map(_buildMediaListCard),
                        if (folder.reports != null &&
                            folder.reports!.isNotEmpty) ...[
                          SizedBox(height: isTab ? 34 : 28),
                          Text('Reports',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: isTab ? 22 : 18,
                                  fontWeight: FontWeight.w700)),
                          SizedBox(height: isTab ? 14 : 12),
                          ...folder.reports!.map((report) => GestureDetector(
                                onTap: () => _openSavedReport(report),
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 12),
                                  padding: const EdgeInsets.all(16),
                                  decoration: AppTheme.softCardDecoration(
                                      borderRadius: BorderRadius.circular(18)),
                                  child: Row(children: [
                                    Container(
                                      width: 72,
                                      height: 72,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF1D284D),
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      child: (report.previewImageUrl != null &&
                                              report.previewImageUrl!.isNotEmpty) ||
                                          (report.previewImageAssetId != null &&
                                              report.previewImageAssetId!.isNotEmpty)
                                          ? ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(14),
                                              child: MediaImage(
                                                source:
                                                    report.previewImageUrl ?? '',
                                                mediaId:
                                                    report.previewImageAssetId,
                                                fit: BoxFit.cover,
                                                errorWidget: const Icon(
                                                    Icons.article_outlined,
                                                    color: Color(0xFF8F5CFF)),
                                              ),
                                            )
                                          : const Icon(Icons.article_outlined,
                                              color: Color(0xFF8F5CFF),
                                              size: 28),
                                    ),
                                    const SizedBox(width: 14),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(report.filename,
                                              style: const TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.w700,
                                                  fontSize: 16)),
                                          const SizedBox(height: 6),
                                          Text(
                                            (report.formData != null &&
                                                    report
                                                        .formData!
                                                        .organizationName
                                                        .isNotEmpty)
                                                ? report
                                                    .formData!.organizationName
                                                : 'Saved report',
                                            style: const TextStyle(
                                                color: Color(0xFFAFC0E4)),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                              _formatTimestamp(
                                                  report.timestamp),
                                              style: const TextStyle(
                                                  color: Color(0xFFAFC0E4),
                                                  fontSize: 13)),
                                        ],
                                      ),
                                    ),
                                    IconButton(
                                      onPressed: () => _downloadReport(report),
                                      icon: const Icon(Icons.download_outlined,
                                          color: AppTheme.textMuted),
                                    ),
                                  ]),
                                ),
                              )),
                        ],
                      ]),
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.fromLTRB(
                24, 12, 24, 16 + MediaQuery.paddingOf(context).bottom),
            decoration: const BoxDecoration(
                color: Color(0xFF141430),
                border: Border(top: BorderSide(color: AppTheme.borderColor))),
            child: SizedBox(
                width: double.infinity, child: _primaryFooterButton(isTab)),
          ),
        ]),
      ),
    );
  }

  Widget _headerStat(IconData icon, String text) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: const Color(0xFFAFC0E4), size: 19),
      const SizedBox(width: 6),
      Text(text, style: const TextStyle(color: Color(0xFFAFC0E4), fontSize: 15))
    ]);
  }

  Widget _roundButton(
      {required IconData icon,
      required VoidCallback onTap,
      required bool isTab,
      bool active = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: isTab ? 50 : 44,
        height: isTab ? 50 : 44,
        decoration: BoxDecoration(
            color: active ? const Color(0xFF2D2C68) : const Color(0xFF232651),
            borderRadius: BorderRadius.circular(25)),
        child: Icon(icon,
            color: active ? Colors.white : AppTheme.textSecondary,
            size: isTab ? 24 : 21),
      ),
    );
  }

  Widget _selectionChip(String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
            color: color.withValues(alpha: 0.14),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: color.withValues(alpha: 0.45))),
        child: Text(label,
            style: TextStyle(
                color: color, fontWeight: FontWeight.w700, fontSize: 12)),
      ),
    );
  }

  Widget _buildMediaCard(ImageData image, double screenWidth) {
    final selected = _selectedImages.contains(image.id);
    final cardWidth = screenWidth >= 1200
        ? 286.0
        : screenWidth >= 900
            ? 240.0
            : screenWidth >= 700
                ? (screenWidth - 72) / 2
                : double.infinity;
    return GestureDetector(
      onTap: () => _onMediaTap(image),
      onLongPressStart: (_) => _queueSelection(image),
      onLongPressEnd: (_) => _longPressTimer?.cancel(),
      child: SizedBox(
        width: cardWidth,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: AppTheme.softCardDecoration(
              borderRadius: BorderRadius.circular(20),
              color: const Color(0xFF2A2C63),
              border:
                  selected ? AppTheme.primaryLight : const Color(0xFF343B7A)),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Stack(children: [
              AspectRatio(
                aspectRatio: 1,
                child: _buildMediaPreview(image),
              ),
              if (image.type == MediaType.video)
                const Positioned.fill(
                  child: Center(
                    child: CircleAvatar(
                      radius: 24,
                      backgroundColor: Color(0x88000000),
                      child: Icon(Icons.play_arrow_rounded,
                          color: Colors.white, size: 28),
                    ),
                  ),
                ),
              if (selected)
                const Positioned(
                    top: 10,
                    right: 10,
                    child: CircleAvatar(
                        radius: 14,
                        backgroundColor: AppTheme.primary,
                        child:
                            Icon(Icons.check, size: 16, color: Colors.white))),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _buildMediaListCard(ImageData image) {
    final selected = _selectedImages.contains(image.id);
    return GestureDetector(
      onTap: () => _onMediaTap(image),
      onLongPressStart: (_) => _queueSelection(image),
      onLongPressEnd: (_) => _longPressTimer?.cancel(),
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.softCardDecoration(
            borderRadius: BorderRadius.circular(20),
            color: const Color(0xFF2A2C63),
            border: selected ? AppTheme.primaryLight : const Color(0xFF343B7A)),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: SizedBox(
              width: 78,
              height: 78,
              child: _buildMediaPreview(image),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(
                    image.type == MediaType.video
                        ? Icons.videocam_outlined
                        : Icons.photo_outlined,
                    color: const Color(0xFF7472FF),
                    size: 16),
                const SizedBox(width: 6),
                Text(
                    image.filename ??
                        (image.type == MediaType.video ? 'Video' : 'Photo'),
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 18))
              ]),
              const SizedBox(height: 6),
              Row(children: [
                const Icon(Icons.calendar_today_outlined,
                    color: Color(0xFFAFC0E4), size: 14),
                const SizedBox(width: 6),
                Text(_formatTimestamp(image.timestamp),
                    style:
                        const TextStyle(color: Color(0xFFAFC0E4), fontSize: 14))
              ]),
            ]),
          ),
          if (selected)
            const Icon(Icons.check_circle_rounded,
                color: AppTheme.primary, size: 24),
        ]),
      ),
    );
  }

  Widget _primaryFooterButton(bool isTab) {
    return SizedBox(
      height: Responsive.bottomBarHeight(context),
      child: ElevatedButton(
        onPressed: () => context.push('/camera/${widget.folderId}'),
        style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            shadowColor: Colors.transparent,
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18))),
        child: Ink(
          decoration: BoxDecoration(
              gradient: AppTheme.buttonGradient,
              borderRadius: BorderRadius.circular(18)),
          child: Center(
              child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.camera_alt_outlined,
                color: Colors.white, size: isTab ? 22 : 20),
            const SizedBox(width: 10),
            Text('Open Camera',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: isTab ? 18 : 16))
          ])),
        ),
      ),
    );
  }

  Widget _placeholder() => Container(
      color: const Color(0xFF1D2249),
      child: const Center(
          child: Icon(Icons.broken_image_outlined,
              color: AppTheme.textMuted, size: 28)));

  Widget _buildMediaPreview(ImageData image) {
    final source = image.thumbnail != null && image.thumbnail!.isNotEmpty
        ? image.thumbnail!
        : image.imageUrl;
    return MediaImage(
      source: source,
      mediaId: image.thumbnailId ?? image.mediaId,
      fit: BoxFit.cover,
      errorWidget: _placeholder(),
    );
  } 

  void _queueSelection(ImageData image) {
    _longPressTimer = Timer(const Duration(milliseconds: 400), () {
      setState(() {
        _selectionMode = true;
        _selectedImages.add(image.id);
      });
    });
  }

  void _onMediaTap(ImageData image) {
    if (_selectionMode) {
      setState(() {
        if (_selectedImages.contains(image.id)) {
          _selectedImages.remove(image.id);
        } else {
          _selectedImages.add(image.id);
        }
      });
      return;
    }
    context.push('/image/${widget.folderId}/${image.id}');
  }

  String _formatTimestamp(String value) {
    final parsed = DateTime.tryParse(value);
    if (parsed == null) return value;
    final hour = parsed.hour % 12 == 0 ? 12 : parsed.hour % 12;
    final minute = parsed.minute.toString().padLeft(2, '0');
    final meridiem = parsed.hour >= 12 ? 'PM' : 'AM';
    return '${parsed.month}/${parsed.day}/${parsed.year}, $hour:$minute:$meridiem';
  }

  void _deleteSelected() {
    ref
        .read(foldersProvider.notifier)
        .removeImages(widget.folderId, _selectedImages);
    setState(() {
      _selectedImages.clear();
      _selectionMode = false;
    });
  }

  void _generateReport() {
    final folder = _getFolder(ref.read(foldersProvider));
    if (folder == null) return;
    final selected = folder.images
        .where((image) => _selectedImages.contains(image.id))
        .toList();
    if (selected.isEmpty) return;
    context.push('/report/${widget.folderId}',
        extra: {'images': selected.map((image) => image.toJson()).toList()});
  }

  void _openSavedReport(ReportData report) {
    context.push(
      '/report/${widget.folderId}',
      extra: {
        'images': report.sourceImages ?? const <Map<String, dynamic>>[],
        'formData': report.formData?.toJson(),
      },
    );
  }

  Future<void> _downloadReport(ReportData report) async {
    if (report.pdfAssetId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Saved PDF not found for this report'),
          backgroundColor: AppTheme.danger,
        ),
      );
      return;
    }
    final bytes = await MediaDatabase.getAsset(report.pdfAssetId!);
    if (bytes == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Unable to load report file'),
          backgroundColor: AppTheme.danger,
        ),
      );
      return;
    }
    await Printing.sharePdf(bytes: bytes, filename: report.filename);
  }
}
