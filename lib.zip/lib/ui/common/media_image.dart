import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../../data/services/database_service.dart';

class MediaImage extends StatelessWidget {
  const MediaImage({
    super.key,
    required this.source,
    this.mediaId,
    this.fit = BoxFit.cover,
    this.errorWidget,
  });

  final String source;
  final String? mediaId;
  final BoxFit fit;
  final Widget? errorWidget;

  @override
  Widget build(BuildContext context) {
    if (source.isEmpty && (mediaId == null || mediaId!.isEmpty)) {
      return _fallback();
    }

    if (kIsWeb && mediaId != null && mediaId!.isNotEmpty) {
      return FutureBuilder<Uint8List?>(
        future: MediaDatabase.getAsset(mediaId!),
        builder: (context, snapshot) {
          final bytes = snapshot.data;
          if (bytes == null || bytes.isEmpty) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator(strokeWidth: 2));
            }
            return _fallback();
          }
          return Image.memory(
            bytes,
            fit: fit,
            errorBuilder: (_, __, ___) => _fallback(),
          );
        },
      );
    }

    if (!kIsWeb && source.startsWith('file://')) {
      return Image.file(
        File(source.replaceFirst('file://', '')),
        fit: fit,
        errorBuilder: (_, __, ___) => _fallback(),
      );
    }

    return Image.network(
      source.startsWith('file://') ? source.replaceFirst('file://', '') : source,
      fit: fit,
      errorBuilder: (_, __, ___) => _fallback(),
    );
  }

  Widget _fallback() =>
      errorWidget ?? const SizedBox.shrink();
}
