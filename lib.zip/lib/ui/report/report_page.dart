import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../config/theme.dart';
import '../../data/models/annotation.dart';
import '../../data/models/image_data.dart';
import '../../data/models/report_data.dart';
import '../../data/services/database_service.dart';
import '../../data/services/file_service.dart';
import '../../state/providers.dart';
import '../../utils/responsive.dart';
import '../common/media_image.dart';

class ReportPage extends ConsumerStatefulWidget {
  final String folderId;
  final Map<String, dynamic>? reportData;
  const ReportPage({super.key, required this.folderId, this.reportData});

  @override
  ConsumerState<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends ConsumerState<ReportPage> {
  final _orgController = TextEditingController(text: 'Organization Name');
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _locationController = TextEditingController();
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    if (widget.reportData != null && widget.reportData!['images'] != null) {
      _items =
          (widget.reportData!['images'] as List).cast<Map<String, dynamic>>();
    }
    final formData = widget.reportData?['formData'];
    if (formData is Map<String, dynamic>) {
      final reportForm = ReportFormData.fromJson(formData);
      _orgController.text = reportForm.organizationName.isEmpty
          ? _orgController.text
          : reportForm.organizationName;
      _nameController.text = reportForm.fullName;
      _emailController.text = reportForm.email;
      _phoneController.text = reportForm.phone;
      _locationController.text = reportForm.location;
    }
  }

  @override
  void dispose() {
    _orgController.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  List<ImageData> get _reportImages =>
      _items.map((item) => ImageData.fromJson(item)).toList();

  ImageData? get _primaryImage =>
      _reportImages.isEmpty ? null : _reportImages.first;

  @override
  Widget build(BuildContext context) {
    final isTab = Responsive.isTablet(context);
    final pad = Responsive.pagePadding(context);
    final maxWidth = MediaQuery.sizeOf(context).width >= 1200 ? 900.0 : 760.0;
    final image = _primaryImage;
    final annotations = image?.annotations ?? const <Annotation>[];

    return Scaffold(
      body: Container(
        color: AppTheme.bgPrimary,
        child: Column(
          children: [
            SafeArea(
              bottom: false,
              child: Container(
                padding: EdgeInsets.fromLTRB(pad, 14, pad, 10),
                decoration: const BoxDecoration(
                  color: Color(0xFF141430),
                  border:
                      Border(bottom: BorderSide(color: AppTheme.borderColor)),
                ),
                child: Row(
                  children: [
                    _circleButton(
                        icon: Icons.arrow_back_rounded,
                        onTap: () => context.pop()),
                    const Spacer(),
                    SizedBox(
                      width: 170,
                      child: _headerAction(
                        icon: Icons.download_outlined,
                        label: 'Download',
                        onTap: () => _generatePDF(),
                      ),
                    ),
                    const SizedBox(width: 12),
                    SizedBox(
                      width: 132,
                      child: _headerAction(
                        icon: Icons.save_alt_outlined,
                        label: 'Save',
                        onTap: () => _saveToFolder(),
                        filled: true,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.fromLTRB(pad, 26, pad, 32),
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: maxWidth),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _sectionCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.description_outlined,
                                      color: Color(0xFF7472FF), size: 28),
                                  const SizedBox(width: 12),
                                  Text(
                                    'Report Details',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: isTab ? 20 : 17,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: isTab ? 26 : 20),
                              LayoutBuilder(
                                builder: (context, constraints) {
                                  final twoColumns = constraints.maxWidth > 640;
                                  final fieldWidth = twoColumns
                                      ? (constraints.maxWidth - 24) / 2
                                      : constraints.maxWidth;
                                  final fields = [
                                    _FieldData(
                                        'Organization Name',
                                        _orgController,
                                        Icons.apartment_rounded,
                                        'Organization Name'),
                                    _FieldData(
                                        'Full Name',
                                        _nameController,
                                        Icons.person_outline_rounded,
                                        'Enter your name'),
                                    _FieldData(
                                        'Email Address',
                                        _emailController,
                                        Icons.alternate_email_rounded,
                                        'your.email@example.com'),
                                    _FieldData(
                                        'Phone Number',
                                        _phoneController,
                                        Icons.call_rounded,
                                        'Enter your phone number'),
                                    _FieldData(
                                        'Location',
                                        _locationController,
                                        Icons.location_on_outlined,
                                        'City, Country'),
                                  ];
                                  return Wrap(
                                    spacing: 24,
                                    runSpacing: 24,
                                    children: fields
                                        .map((field) => SizedBox(
                                            width: fieldWidth,
                                            child: _inputField(field)))
                                        .toList(),
                                  );
                                },
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: isTab ? 28 : 22),
                        _sectionCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                      Icons.settings_input_component_outlined,
                                      color: Color(0xFF7472FF),
                                      size: 26),
                                  const SizedBox(width: 12),
                                  Text(
                                    'Camera Settings',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: isTab ? 20 : 17,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: isTab ? 24 : 20),
                              Wrap(
                                spacing: 16,
                                runSpacing: 16,
                                children: [
                                  _MetricCard(
                                      label: 'Exposure',
                                      value:
                                          '${(image?.cameraSettings.exposure ?? 100).round()}%'),
                                  _MetricCard(
                                      label: 'ISO',
                                      value:
                                          '${(image?.cameraSettings.iso ?? 400).round()}'),
                                  _MetricCard(
                                      label: 'Temperature',
                                      value:
                                          '${(image?.cameraSettings.temperature ?? 6500).round()}K'),
                                  _MetricCard(
                                      label: 'Tint',
                                      value:
                                          '${(image?.cameraSettings.tint ?? 0).round()}'),
                                  _MetricCard(
                                      label: 'Objective',
                                      value: image?.lens ?? '4X',
                                      highlight: true),
                                ],
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: isTab ? 28 : 22),
                        if (image != null)
                          _sectionCard(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Marked Image',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    fontSize: isTab ? 20 : 17,
                                  ),
                                ),
                                const SizedBox(height: 18),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(18),
                                  child: Container(
                                    width: double.infinity,
                                    constraints: BoxConstraints(
                                        minHeight: isTab ? 280 : 220),
                                    color: const Color(0xFF1D284D),
                                    child: _buildPreviewImage(image),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        if (image != null) SizedBox(height: isTab ? 28 : 22),
                        _sectionCard(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Summary',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: isTab ? 20 : 17,
                                ),
                              ),
                              SizedBox(height: isTab ? 24 : 20),
                              Wrap(
                                spacing: 56,
                                runSpacing: 18,
                                children: [
                                  _summaryMetric('Total Annotations',
                                      '${annotations.length}'),
                                  _summaryMetric(
                                      'Measurement Mode',
                                      annotations.any((annotation) =>
                                              (annotation.measurement ?? '')
                                                  .isNotEmpty)
                                          ? 'ON'
                                          : 'OFF'),
                                ],
                              ),
                              if (annotations.isNotEmpty) ...[
                                SizedBox(height: isTab ? 24 : 20),
                                const Divider(color: AppTheme.borderColor),
                                SizedBox(height: isTab ? 18 : 14),
                                ...annotations.asMap().entries.map(
                                      (entry) => Padding(
                                        padding:
                                            const EdgeInsets.only(bottom: 12),
                                        child: _annotationRow(
                                            entry.key + 1, entry.value),
                                      ),
                                    ),
                              ],
                            ],
                          ),
                        ),
                        SizedBox(height: isTab ? 30 : 24),
                        _footerBrand(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPreviewImage(ImageData image) {
    return MediaImage(
      source: image.imageUrl,
      mediaId: image.mediaId,
      fit: BoxFit.cover,
      errorWidget: const Center(
          child: Icon(Icons.broken_image_outlined, color: AppTheme.textMuted)),
    );
  }

  Widget _annotationRow(int index, Annotation annotation) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1D284D),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: const BoxDecoration(
              color: Color(0xFF343B7A),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text('$index',
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _annotationTitle(annotation.type),
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                Text(
                  annotation.measurement?.isNotEmpty == true
                      ? annotation.measurement!
                      : 'Marked without measurement label',
                  style:
                      const TextStyle(color: Color(0xFFAFC0E4), height: 1.35),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _annotationTitle(AnnotationType type) {
    switch (type) {
      case AnnotationType.draw:
        return 'Free Draw';
      case AnnotationType.text:
        return 'Text Label';
      case AnnotationType.arrow:
      case AnnotationType.arrowOneWay:
        return 'Arrow';
      case AnnotationType.circle:
        return 'Circle';
      case AnnotationType.rectangle:
      case AnnotationType.square:
        return 'Rectangle';
      case AnnotationType.twoPointer:
        return 'Distance';
      case AnnotationType.singlePointer:
        return 'Point Marker';
    }
  }

  Widget _circleButton({required IconData icon, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
            color: const Color(0xFF232651),
            borderRadius: BorderRadius.circular(22)),
        child: Icon(icon, color: Colors.white),
      ),
    );
  }

  Widget _headerAction(
      {required IconData icon,
      required String label,
      required VoidCallback onTap,
      bool filled = false}) {
    return SizedBox(
      height: 50,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor:
              filled ? Colors.transparent : const Color(0xFF232651),
          shadowColor: Colors.transparent,
          padding: EdgeInsets.zero,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
        child: Ink(
          decoration: BoxDecoration(
            gradient: filled ? AppTheme.buttonGradient : null,
            color: filled ? null : const Color(0xFF232651),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: Colors.white),
                const SizedBox(width: 10),
                Text(label,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionCard({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: AppTheme.softCardDecoration(
          borderRadius: BorderRadius.circular(22),
          color: const Color(0xFF2A295D)),
      child: child,
    );
  }

  Widget _inputField(_FieldData field) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(field.icon, color: const Color(0xFFC6CAE8), size: 20),
            const SizedBox(width: 8),
            Text(field.label,
                style: const TextStyle(color: Colors.white, fontSize: 15)),
          ],
        ),
        const SizedBox(height: 12),
        TextField(
          controller: field.controller,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: field.hint,
            hintStyle: const TextStyle(color: AppTheme.textMuted),
            filled: true,
            fillColor: const Color(0xFF1D284D),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xFF35517A))),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: Color(0xFF35517A))),
            focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: const BorderSide(color: AppTheme.primaryLight)),
          ),
        ),
      ],
    );
  }

  Widget _summaryMetric(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(color: Color(0xFFAFC0E4), fontSize: 14)),
        const SizedBox(height: 8),
        Text(value,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w800)),
      ],
    );
  }

  Widget _footerBrand() {
    return Container(
      padding: const EdgeInsets.only(top: 22),
      decoration: const BoxDecoration(
          border: Border(top: BorderSide(color: AppTheme.borderColor))),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(Icons.hexagon_outlined, color: Color(0xFF8F5CFF), size: 30),
              SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Hexa-Cam',
                      style: TextStyle(
                          color: Color(0xFF8F5CFF),
                          fontSize: 18,
                          fontWeight: FontWeight.w700)),
                  Text('Scientific Imaging & Microscopy',
                      style: TextStyle(color: Color(0xFFAFC0E4), fontSize: 13)),
                ],
              ),
            ],
          ),
          Flexible(
            child: Text(
              'Generated by Hexa-Cam - Scientific Imaging & Microscopy Platform\n© 2026 All Rights Reserved',
              textAlign: TextAlign.right,
              style: TextStyle(color: Color(0xFFAFC0E4), fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Future<Uint8List> _buildReportPdf() async {
    final image = _primaryImage;
    final pdf = pw.Document();
    final imageProvider = await _loadPdfImage(image?.imageUrl);
    final annotations = image?.annotations ?? const <Annotation>[];
    final now = DateTime.now();

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(20),
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Expanded(
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(
                        _orgController.text.trim().isEmpty
                            ? 'Organization Name'
                            : _orgController.text.trim(),
                        style: pw.TextStyle(
                            fontSize: 24, fontWeight: pw.FontWeight.bold),
                      ),
                      pw.SizedBox(height: 8),
                      pw.Text(
                          'Email: ${_emailController.text.isEmpty ? '-' : _emailController.text}    Full Name: ${_nameController.text.isEmpty ? '-' : _nameController.text}'),
                      pw.SizedBox(height: 4),
                      pw.Text(
                          'Phone: ${_phoneController.text.isEmpty ? '-' : _phoneController.text}'),
                      pw.SizedBox(height: 4),
                      pw.Text(
                          'Address: ${_locationController.text.isEmpty ? '-' : _locationController.text}'),
                    ],
                  ),
                ),
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Text('Page: 1 of 1',
                        style: const pw.TextStyle(fontSize: 10)),
                    pw.SizedBox(height: 6),
                    pw.Text('Date: ${now.day}-${now.month}-${now.year}',
                        style: const pw.TextStyle(fontSize: 10)),
                  ],
                ),
              ],
            ),
            pw.SizedBox(height: 16),
            pw.Divider(color: PdfColors.grey300),
            pw.SizedBox(height: 14),
            pw.Row(
              children: [
                pw.Text('Camera Settings',
                    style: pw.TextStyle(
                        fontSize: 18, fontWeight: pw.FontWeight.bold)),
              ],
            ),
            pw.SizedBox(height: 12),
            pw.Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _pdfMetric('Exposure',
                    '${(image?.cameraSettings.exposure ?? 100).round()}%'),
                _pdfMetric(
                    'ISO', '${(image?.cameraSettings.iso ?? 400).round()}'),
                _pdfMetric('Temperature',
                    '${(image?.cameraSettings.temperature ?? 6500).round()}K'),
                _pdfMetric(
                    'Tint', '${(image?.cameraSettings.tint ?? 0).round()}'),
              ],
            ),
            pw.SizedBox(height: 18),
            if (imageProvider != null)
              pw.Container(
                height: 260,
                width: double.infinity,
                decoration: const pw.BoxDecoration(color: PdfColors.grey100),
                child: pw.Image(imageProvider, fit: pw.BoxFit.cover),
              ),
            pw.SizedBox(height: 18),
            pw.Text('Marking Details',
                style:
                    pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 10),
            if (annotations.isEmpty)
              pw.Text('No markings available')
            else
              ...annotations.asMap().entries.map(
                    (entry) => pw.Padding(
                      padding: const pw.EdgeInsets.only(bottom: 8),
                      child: pw.Text(
                          '${entry.key + 1}. ${_annotationTitle(entry.value.type)}${(entry.value.measurement ?? '').isNotEmpty ? ' - ${entry.value.measurement}' : ''}'),
                    ),
                  ),
            pw.Spacer(),
            pw.Divider(color: PdfColors.grey300),
            pw.SizedBox(height: 10),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Hexa-Cam',
                    style: pw.TextStyle(
                        fontSize: 16,
                        fontWeight: pw.FontWeight.bold,
                        color: PdfColor.fromHex('#7C5CFF'))),
                pw.Text(
                    'Generated by Hexa-Cam - Scientific Imaging & Microscopy Platform\n© 2026 All Rights Reserved',
                    textAlign: pw.TextAlign.right,
                    style: const pw.TextStyle(fontSize: 10)),
              ],
            ),
          ],
        ),
      ),
    );

    return pdf.save();
  }

  bool _validateForm() {
    if (_orgController.text.trim().isEmpty ||
        _nameController.text.trim().isEmpty ||
        _emailController.text.trim().isEmpty ||
        _locationController.text.trim().isEmpty) {
      _showMessage(
        'Fill organization, name, email, and location before generating the report',
        AppTheme.danger,
      );
      return false;
    }
    return true;
  }

  Future<void> _generatePDF() async {
    if (!_validateForm()) return;
    final bytes = await _buildReportPdf();
    final filename = 'report-${DateTime.now().millisecondsSinceEpoch}.pdf';
    await Printing.sharePdf(bytes: bytes, filename: filename);
  }

  pw.Widget _pdfMetric(String label, String value) {
    return pw.Container(
      width: 120,
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey200,
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Text(label, style: const pw.TextStyle(fontSize: 10)),
          pw.SizedBox(height: 8),
          pw.Text(value,
              style:
                  pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
        ],
      ),
    );
  }

  Future<pw.ImageProvider?> _loadPdfImage(String? source) async {
    if (source == null || source.isEmpty) return null;
    try {
      final image = _primaryImage;
      if (image?.mediaId != null && image!.mediaId!.isNotEmpty) {
        final bytes = await MediaDatabase.getAsset(image.mediaId!);
        if (bytes != null && bytes.isNotEmpty) {
          return pw.MemoryImage(bytes);
        }
      }
      if (!kIsWeb && source.startsWith('file://')) {
        final bytes = await FileService.readBytes(
          source.replaceFirst('file://', ''),
        );
        return pw.MemoryImage(bytes);
      }
      return await networkImage(source);
    } catch (_) {
      return null;
    }
  }

  Future<void> _saveToFolder() async {
    if (!_validateForm()) return;
    final bytes = await _buildReportPdf();
    final filename = 'report-${DateTime.now().millisecondsSinceEpoch}.pdf';
    final savedPath = await FileService.persistBytes(
      bytes: bytes,
      filename: filename,
      folderName: widget.folderId,
    );
    final assetId = FileService.generateAssetId('report');
    await MediaDatabase.saveAsset(assetId, bytes);

    final preview =
        _items.isNotEmpty ? (_items.first['imageUrl'] as String?) : null;
    final primaryImage = _primaryImage;
    final report = ReportData(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      filename: filename,
      timestamp: DateTime.now().toIso8601String(),
      pdfAssetId: assetId,
      previewImageUrl: preview ?? 'file://$savedPath',
      description: 'Annotations: ${primaryImage?.annotations.length ?? 0}',
      lens: primaryImage?.lens,
      formData: ReportFormData(
        organizationName: _orgController.text,
        fullName: _nameController.text,
        email: _emailController.text,
        phone: _phoneController.text,
        location: _locationController.text,
      ),
      sourceImages: _items,
    );
    ref.read(foldersProvider.notifier).addReport(widget.folderId, report);
    _showMessage('Report saved to folder', AppTheme.success);
    context.pop();
  }

  void _showMessage(String text, Color backgroundColor) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), backgroundColor: backgroundColor),
    );
  }
}

class _FieldData {
  const _FieldData(this.label, this.controller, this.icon, this.hint);
  final String label;
  final TextEditingController controller;
  final IconData icon;
  final String hint;
}

class _MetricCard extends StatelessWidget {
  const _MetricCard(
      {required this.label, required this.value, this.highlight = false});
  final String label;
  final String value;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 152,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
          color: const Color(0xFF1D284D),
          borderRadius: BorderRadius.circular(18)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: Color(0xFFAFC0E4), fontSize: 14)),
          const SizedBox(height: 10),
          Text(value,
              style: TextStyle(
                  color: highlight ? const Color(0xFF00E0FF) : Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}
