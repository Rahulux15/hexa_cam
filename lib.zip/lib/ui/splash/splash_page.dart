import 'dart:math';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../utils/responsive.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late Animation<double> _scaleAnimation;
  late List<_Particle> _particles;
  final _random = Random();

  @override
  void initState() {
    super.initState();

    // Scale animation for logo
    _scaleController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.easeInOut),
    );

    _particles = List.generate(
      10,
          (_) => _Particle(
        x: _random.nextDouble(),
        y: _random.nextDouble(),
        controller: AnimationController(
          duration: Duration(milliseconds: 3000 + _random.nextInt(2000)),
          vsync: this,
        )..repeat(reverse: true),
      ),
    );

    Future.delayed(const Duration(milliseconds: 2500), () {
      if (mounted) context.go('/login');
    });
  }

  @override
  void dispose() {
    _scaleController.dispose();
    for (final p in _particles) {
      p.controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isTab = Responsive.isTablet(context);
    final particleSize = isTab ? 6.0 : 4.0;

    return Scaffold(
      body: Container(
        constraints: const BoxConstraints(minWidth: double.infinity, minHeight: double.infinity),
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF0F0F23), Color(0xFF1A1A2E), Color(0xFF16213E)],
            stops: [0.0, 0.5, 1.0],
          ),
        ),
        child: Stack(children: [
          ..._particles.map((p) => AnimatedBuilder(
            animation: p.controller,
            builder: (_, __) => Positioned(
              left: MediaQuery.sizeOf(context).width * p.x,
              top: MediaQuery.sizeOf(context).height * p.y,
              child: Opacity(
                opacity: 0.2 + p.controller.value * 0.4,
                child: Container(
                  width: particleSize,
                  height: particleSize,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFFA78BFA),
                  ),
                ),
              ),
            ),
          )),
          Center(
            child: AnimatedBuilder(
              animation: _scaleController,
              builder: (context, child) {
                return Transform.scale(
                  scale: _scaleAnimation.value,
                  child: Image.asset(
                    'assets/images/logo.png',
                    width: 150,
                    height: 300,
                    fit: BoxFit.contain,
                  ),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }
}

class _Particle {
  final double x;
  final double y;
  final AnimationController controller;
  _Particle({
    required this.x,
    required this.y,
    required this.controller,
  });
}