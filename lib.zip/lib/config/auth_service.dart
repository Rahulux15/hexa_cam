// lib/core/services/auth_service.dart

import 'database_helper.dart';

class AuthService {
  final DatabaseHelper _dbHelper = DatabaseHelper();

  // Check internet connection
  Future<bool> hasInternetConnection() async {
    List<ConnectivityResult> results = await Connectivity().checkConnectivity();
    return results.contains(ConnectivityResult.wifi) ||
        results.contains(ConnectivityResult.mobile) ||
        results.contains(ConnectivityResult.ethernet);
  }

  // Online login
  Future<LoginResult> loginOnline(String email, String password) async {
    try {
      bool isValid = await _dbHelper.validateUser(email, password);

      if (isValid) {
        String token = 'token_${DateTime.now().millisecondsSinceEpoch}';
        Map<String, dynamic>? user = await _dbHelper.getUserByEmail(email);

        if (user != null) {
          await _dbHelper.saveSession(user['id'], token, 'online');
          return LoginResult.success(
            token: token,
            userData: UserData(
              id: user['id'],
              email: user['email'],
              fullName: user['full_name'] ?? '',
              role: user['role'],
            ),
          );
        }
      }
      return LoginResult.failure(message: 'Invalid email or password');
    } catch (e) {
      return LoginResult.failure(message: 'Login failed: $e');
    }
  }

  // Offline login
  Future<LoginResult> loginOffline(String email, String password) async {
    try {
      bool isValid = await _dbHelper.validateUser(email, password);

      if (isValid) {
        bool hasPreviousLogin = await _dbHelper.hasPreviousLogin();

        if (hasPreviousLogin) {
          Map<String, dynamic>? user = await _dbHelper.getUserByEmail(email);
          Map<String, dynamic>? lastSession = await _dbHelper.getLastLoginInfo();

          if (user != null) {
            String token = lastSession != null
                ? lastSession['token']
                : 'offline_${DateTime.now().millisecondsSinceEpoch}';

            await _dbHelper.saveSession(user['id'], token, 'offline');

            return LoginResult.success(
              token: token,
              userData: UserData(
                id: user['id'],
                email: user['email'],
                fullName: user['full_name'] ?? '',
                role: user['role'],
              ),
              isOffline: true,
            );
          }
        }
        return LoginResult.failure(message: 'No offline access. Please connect to internet first.');
      }
      return LoginResult.failure(message: 'Invalid credentials');
    } catch (e) {
      return LoginResult.failure(message: 'Offline login failed: $e');
    }
  }

  // Main login method
  Future<LoginResult> login(String email, String password) async {
    bool isConnected = await hasInternetConnection();

    if (isConnected) {
      LoginResult result = await loginOnline(email, password);
      if (result.isSuccess) {
        return result;
      } else {
        if (await _dbHelper.hasPreviousLogin()) {
          return await loginOffline(email, password);
        }
        return result;
      }
    } else {
      return await loginOffline(email, password);
    }
  }

  // Check if user is logged in
  Future<bool> isLoggedIn() async {
    Map<String, dynamic>? session = await _dbHelper.getActiveSession();
    return session != null;
  }

  // Get current user
  Future<UserData?> getCurrentUser() async {
    Map<String, dynamic>? session = await _dbHelper.getActiveSession();
    if (session != null && session['user'] != null) {
      Map<String, dynamic> user = session['user'];
      return UserData(
        id: user['id'],
        email: user['email'],
        fullName: user['full_name'] ?? '',
        role: user['role'],
      );
    }
    return null;
  }

  // Get last login info
  Future<Map<String, dynamic>?> getLastLoginInfo() async {
    return await _dbHelper.getLastLoginInfo();
  }

  // Logout
  Future<void> logout() async {
    await _dbHelper.clearSession();
  }
}

// Models
class LoginResult {
  final bool isSuccess;
  final String? token;
  final UserData? userData;
  final String? errorMessage;
  final bool isOffline;

  LoginResult.success({
    required this.token,
    required this.userData,
    this.isOffline = false,
  }) : isSuccess = true, errorMessage = null;

  LoginResult.failure({
    required this.message,
  }) : isSuccess = false,
        token = null,
        userData = null,
        isOffline = false,
        errorMessage = message;

  String get message => errorMessage ?? '';
}

class UserData {
  final int? id;
  final String email;
  final String fullName;
  final String role;

  UserData({
    this.id,
    required this.email,
    required this.fullName,
    required this.role,
  });
}