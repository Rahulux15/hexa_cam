import 'package:flutter/material.dart';

/// Responsive breakpoints and helpers - Exact from specification
class Responsive {
  Responsive._();

  // Breakpoints - Exact from specification
  static const double phoneMax = 600;    // Mobile max
  static const double tabletMin = 600;   // Tablet min
  static const double tabletMax = 1024;  // Tablet max
  static const double desktopMin = 1024; // Desktop min

  // Landscape tablet breakpoint
  static const double landscapeTabletMin = 700;
  static const double landscapeTabletMax = 1024;

  /// True when shortest side >= 600 (iPad mini, Android tablets).
  static bool isTablet(BuildContext context) =>
      MediaQuery.sizeOf(context).shortestSide >= tabletMin;

  /// True when width >= 1024 (large tablets in landscape).
  static bool isLargeTablet(BuildContext context) =>
      MediaQuery.sizeOf(context).width >= tabletMax;

  /// True when width >= 1024 (desktop).
  static bool isDesktop(BuildContext context) =>
      MediaQuery.sizeOf(context).width >= desktopMin;

  /// Landscape tablet: min-width 700px and min-height 500px and orientation landscape
  static bool isLandscapeTablet(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final orientation = MediaQuery.orientationOf(context);
    return size.width >= landscapeTabletMin &&
           size.height >= 500 &&
           orientation == Orientation.landscape;
  }

  static bool isPortrait(BuildContext context) =>
      MediaQuery.orientationOf(context) == Orientation.portrait;

  static bool isLandscape(BuildContext context) =>
      MediaQuery.orientationOf(context) == Orientation.landscape;

  static bool isCompactHeight(BuildContext context) =>
      MediaQuery.sizeOf(context).height < 720;

  /// Adaptive value: returns [phone] on phones, [tablet] on tablets.
  static T value<T>(BuildContext context, {required T phone, required T tablet}) =>
      isTablet(context) ? tablet : phone;

  /// Adaptive value for desktop: returns [phone] on phones, [tablet] on tablets, [desktop] on desktop.
  static T value3<T>(BuildContext context, {
    required T phone,
    required T tablet,
    required T desktop
  }) {
    if (isDesktop(context)) return desktop;
    if (isTablet(context)) return tablet;
    return phone;
  }

  /// Number of grid columns for the current screen width.
  /// Folder grid: 1→2→3→4→5 columns
  static int gridColumns(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    if (w >= 1280) return 5;  // xl
    if (w >= 1024) return 4;  // lg
    if (w >= 768) return 3;   // md
    if (w >= 640) return 2;   // sm
    return 1;                // mobile
  }

  /// Stats grid columns: 2→4 columns
  static int statsGridColumns(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    if (w >= 640) return 4;   // md+
    return 2;                // mobile
  }

  /// Media grid columns: 2→3→4 columns
  static int mediaGridColumns(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    if (w >= 1024) return 4;  // lg
    if (w >= 768) return 3;   // md
    return 2;                // mobile
  }

  /// Tools grid columns: 4→6 columns
  static int toolsColumns(BuildContext context) {
    return isTablet(context) ? 6 : 4;
  }

  /// Content max width – keeps forms/cards from stretching edge-to-edge on tablets.
  static double contentMaxWidth(BuildContext context) =>
      isTablet(context) ? 720 : double.infinity;

  /// Horizontal page padding.
  static double pagePadding(BuildContext context) =>
      value(context, phone: 14.0, tablet: 20.0);

  /// Adaptive font scale factor for headings.
  static double fontScale(BuildContext context) =>
      isTablet(context) ? 1.15 : 1.0;

  /// Icon size scaled for tablets.
  static double iconSize(BuildContext context, {double base = 24}) =>
      isTablet(context) ? base * 1.2 : base;

  /// Button height scaled for tablets.
  static double buttonHeight(BuildContext context) =>
      value(context, phone: 44.0, tablet: 50.0);

  /// Bottom bar action button height.
  static double bottomBarHeight(BuildContext context) =>
      value(context, phone: 42.0, tablet: 50.0);

  /// AppBar icon/back button size.
  static double appBarIconSize(BuildContext context) =>
      value(context, phone: 40.0, tablet: 48.0);

  /// Grid child aspect ratio for folder cards.
  static double statCardAspect(BuildContext context) =>
      value(context, phone: 1.5, tablet: 1.8);

  /// Folder card icon size
  static double folderIconSize(BuildContext context) =>
      value(context, phone: 48.0, tablet: 56.0);

  /// Wraps [child] in a Center + ConstrainedBox so it doesn't stretch on tablets.
  static Widget constrain(BuildContext context, {
    required Widget child,
    double? maxWidth,
    EdgeInsetsGeometry? padding,
  }) {
    return Center(
      child: Padding(
        padding: padding ?? EdgeInsets.symmetric(horizontal: pagePadding(context)),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: maxWidth ?? contentMaxWidth(context)),
          child: child,
        ),
      ),
    );
  }

  /// Responsive padding for containers
  static EdgeInsets padding(BuildContext context, {
    double horizontal = 0,
    double vertical = 0,
  }) {
    final pad = pagePadding(context);
    return EdgeInsets.symmetric(
      horizontal: horizontal > 0 ? horizontal : pad,
      vertical: vertical,
    );
  }

  /// Safe area aware padding
  static EdgeInsets safePadding(BuildContext context, {
    double horizontal = 0,
    double vertical = 0,
    bool includeBottom = true,
  }) {
    final mediaQuery = MediaQuery.of(context);
    final pad = pagePadding(context);
    return EdgeInsets.fromLTRB(
      horizontal > 0 ? horizontal : pad,
      vertical > 0 ? vertical : pad + mediaQuery.padding.top,
      horizontal > 0 ? horizontal : pad,
      vertical > 0 ? vertical : (includeBottom ? pad + mediaQuery.padding.bottom : pad),
    );
  }

  /// Camera chrome padding for landscape tablets
  static EdgeInsets cameraChromePadding(BuildContext context) {
    if (isLandscapeTablet(context)) {
      return const EdgeInsets.symmetric(horizontal: 32, vertical: 16);
    }
    return EdgeInsets.symmetric(horizontal: pagePadding(context), vertical: 16);
  }

  /// Camera preview padding for landscape tablets
  static EdgeInsets cameraPreviewPadding(BuildContext context) {
    if (isLandscapeTablet(context)) {
      // clamp(3rem, 9vh, 5.5rem) top/bottom, clamp(5rem, 7vw, 6.5rem) left, clamp(6.5rem, 8vw, 8rem) right
      final vh = MediaQuery.sizeOf(context).height / 100;
      final vw = MediaQuery.sizeOf(context).width / 100;
      return EdgeInsets.only(
        top: (3 * 16).clamp(9 * vh, 5.5 * 16).toDouble(),
        left: (5 * 16).clamp(7 * vw, 6.5 * 16).toDouble(),
        right: (6.5 * 16).clamp(8 * vw, 8 * 16).toDouble(),
        bottom: (3 * 16).clamp(9 * vh, 5.5 * 16).toDouble(),
      );
    }
    return EdgeInsets.all(pagePadding(context));
  }

  /// Camera media window constraints
  static BoxConstraints cameraMediaConstraints(BuildContext context) {
    if (isLandscapeTablet(context)) {
      // min(calc(100% - 2rem), 72vw, 70rem) width, min(calc(100% - 2rem), 76vh, 50rem) height
      final size = MediaQuery.sizeOf(context);
      final maxWidth = (size.width - 32).clamp(0.0, 72 * size.width / 100).clamp(0.0, 70 * 16.0);
      final maxHeight = (size.height - 32).clamp(0.0, 76 * size.height / 100).clamp(0.0, 50 * 16.0);
      return BoxConstraints(maxWidth: maxWidth, maxHeight: maxHeight);
    }
    return const BoxConstraints.expand();
  }

  /// Tools panel width for landscape tablets
  static double toolsPanelWidth(BuildContext context) {
    if (isLandscapeTablet(context)) {
      // min(15rem, 23vw)
      final vw = MediaQuery.sizeOf(context).width / 100;
      return (15 * 16.0).clamp(0.0, 23 * vw).toDouble();
    }
    return double.infinity;
  }

  /// Tools panel max height for tablets
  static double toolsPanelMaxHeight(BuildContext context) {
    // min(70dvh, 32rem)
    final dvh = MediaQuery.sizeOf(context).height / 100;
    return (70 * dvh).clamp(0, 32 * 16);
  }

  /// Tools panel bottom offset
  static double toolsPanelBottomOffset(BuildContext context) {
    // calc(88px + env(safe-area-inset-bottom))
    return 88 + MediaQuery.of(context).padding.bottom;
  }

  /// Action buttons vertical offset for landscape
  static double cameraActionsVerticalOffset(BuildContext context) {
    if (isLandscapeTablet(context)) {
      return MediaQuery.sizeOf(context).height / 2 - 60; // Center vertically
    }
    return 0;
  }
}
