// Annotation system models and painter - Exact from specification

import 'dart:math';
import 'package:flutter/material.dart';

enum AnnotationType {
  draw,
  text,
  arrow,
  arrowOneWay,
  circle,
  rectangle,
  square,
  twoPointer,
  singlePointer,
}

class HexaPoint {
  final double x;
  final double y;

  const HexaPoint(this.x, this.y);

  factory HexaPoint.fromJson(dynamic json) {
    if (json is Map<String, dynamic>) {
      return HexaPoint(json['x']?.toDouble() ?? 0, json['y']?.toDouble() ?? 0);
    }
    return const HexaPoint(0, 0);
  }

  Map<String, dynamic> toJson() => {'x': x, 'y': y};

  Offset toOffset() => Offset(x, y);

  HexaPoint copyWith({double? x, double? y}) => HexaPoint(x ?? this.x, y ?? this.y);

  @override
  String toString() => 'HexaPoint($x, $y)';
}

class Annotation {
  final String id;
  final AnnotationType type;
  final List<HexaPoint> points;
  final String? text;
  final Color color;
  final double strokeWidth;
  final String timestamp;
  final String? measurement;
  final String? coordinateSpace; // 'display' or 'source'

  const Annotation({
    required this.id,
    required this.type,
    required this.points,
    this.text,
    required this.color,
    this.strokeWidth = 3.0,
    required this.timestamp,
    this.measurement,
    this.coordinateSpace = 'source',
  });

  factory Annotation.fromJson(Map<String, dynamic> json) => Annotation(
    id: json['id'] ?? '',
    type: AnnotationType.values.byName(json['type'] ?? 'draw'),
    points: (json['points'] as List?)?.map((p) => HexaPoint.fromJson(p)).toList() ?? [],
    text: json['text'],
    color: Color(json['color'] ?? 0xFFFF00FF),
    strokeWidth: (json['strokeWidth'] ?? 3.0).toDouble(),
    timestamp: json['timestamp'] ?? '',
    measurement: json['measurement'],
    coordinateSpace: json['coordinateSpace'] ?? 'source',
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'type': type.name,
    'points': points.map((p) => p.toJson()).toList(),
    if (text != null) 'text': text,
    'color': color.toARGB32(),
    'strokeWidth': strokeWidth,
    'timestamp': timestamp,
    if (measurement != null) 'measurement': measurement,
    if (coordinateSpace != null) 'coordinateSpace': coordinateSpace,
  };

  Annotation copyWith({
    List<HexaPoint>? points,
    String? coordinateSpace,
    String? measurement,
  }) => Annotation(
    id: id,
    type: type,
    points: points ?? this.points,
    text: text,
    color: color,
    strokeWidth: strokeWidth,
    timestamp: timestamp,
    measurement: measurement ?? this.measurement,
    coordinateSpace: coordinateSpace ?? this.coordinateSpace,
  );

  // Convert from display coordinates to source coordinates
  Annotation toSourceSpace(Size displaySize, Size sourceSize) {
    if (coordinateSpace == 'source') return this;

    final scaleX = sourceSize.width / displaySize.width;
    final scaleY = sourceSize.height / displaySize.height;

    final convertedPoints = points.map((p) => HexaPoint(p.x * scaleX, p.y * scaleY)).toList();

    return copyWith(points: convertedPoints, coordinateSpace: 'source');
  }

  // Convert from source coordinates to display coordinates
  Annotation toDisplaySpace(Size displaySize, Size sourceSize) {
    if (coordinateSpace == 'display') return this;

    final scaleX = displaySize.width / sourceSize.width;
    final scaleY = displaySize.height / sourceSize.height;

    final convertedPoints = points.map((p) => HexaPoint(p.x * scaleX, p.y * scaleY)).toList();

    return copyWith(points: convertedPoints, coordinateSpace: 'display');
  }
}

class AnnotationPainter extends CustomPainter {
  final List<Annotation> annotations;
  final Annotation? currentDrawing;
  final Size displaySize;
  final Size sourceSize;

  AnnotationPainter({
    required this.annotations,
    this.currentDrawing,
    required this.displaySize,
    required this.sourceSize,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Convert all annotations to display space for painting
    final displayAnnotations = annotations.map((a) => a.toDisplaySpace(displaySize, sourceSize)).toList();
    final displayCurrent = currentDrawing?.toDisplaySpace(displaySize, sourceSize);

    // Paint completed annotations
    for (final annotation in displayAnnotations) {
      _paintAnnotation(canvas, annotation, size);
    }

    // Paint current drawing annotation
    if (displayCurrent != null) {
      _paintAnnotation(canvas, displayCurrent, size);
    }
  }

  void _paintAnnotation(Canvas canvas, Annotation annotation, Size canvasSize) {
    if (annotation.points.isEmpty) return;

    final paint = Paint()
      ..color = annotation.color
      ..strokeWidth = annotation.strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path();
    final points = annotation.points.map((p) => p.toOffset()).toList();

    switch (annotation.type) {
      case AnnotationType.draw:
        if (points.length >= 2) {
          path.moveTo(points[0].dx, points[0].dy);
          for (int i = 1; i < points.length; i++) {
            path.lineTo(points[i].dx, points[i].dy);
          }
        }
        break;

      case AnnotationType.arrow:
      case AnnotationType.arrowOneWay:
        if (points.length >= 2) {
          _drawArrow(canvas, points[0], points[1], paint, annotation.type == AnnotationType.arrowOneWay);
        }
        break;

      case AnnotationType.twoPointer:
        if (points.length >= 2) {
          _drawTwoPointer(canvas, points[0], points[1], paint);
        }
        break;

      case AnnotationType.singlePointer:
        if (points.isNotEmpty) {
          _drawSinglePointer(canvas, points[0], paint);
        }
        break;

      case AnnotationType.circle:
        if (points.length >= 2) {
          final center = points[0];
          final radius = (points[1] - center).distance;
          canvas.drawCircle(center, radius, paint);
        }
        break;

      case AnnotationType.rectangle:
        if (points.length >= 2) {
          final rect = Rect.fromPoints(points[0], points[1]);
          canvas.drawRect(rect, paint);
        }
        break;

      case AnnotationType.square:
        if (points.length >= 2) {
          final side = min((points[1].dx - points[0].dx).abs(), (points[1].dy - points[0].dy).abs());
          final rect = Rect.fromLTWH(points[0].dx, points[0].dy, side, side);
          canvas.drawRect(rect, paint);
        }
        break;

      case AnnotationType.text:
        if (annotation.text != null && points.isNotEmpty) {
          _drawText(canvas, points[0], annotation.text!, annotation.color);
        }
        break;
    }

    // Always draw the path if it has commands
    canvas.drawPath(path, paint);
  }

  void _drawArrow(Canvas canvas, Offset start, Offset end, Paint paint, bool oneWay) {
    canvas.drawLine(start, end, paint);

    // Arrowhead
    final angle = atan2(end.dy - start.dy, end.dx - start.dx);
    const arrowLength = 20.0;
    const arrowAngle = pi / 6;

    final arrowP1 = Offset(
      end.dx - arrowLength * cos(angle - arrowAngle),
      end.dy - arrowLength * sin(angle - arrowAngle),
    );
    final arrowP2 = Offset(
      end.dx - arrowLength * cos(angle + arrowAngle),
      end.dy - arrowLength * sin(angle + arrowAngle),
    );

    final arrowPath = Path()
      ..moveTo(end.dx, end.dy)
      ..lineTo(arrowP1.dx, arrowP1.dy)
      ..moveTo(end.dx, end.dy)
      ..lineTo(arrowP2.dx, arrowP2.dy);

    canvas.drawPath(arrowPath, paint);

    if (!oneWay) {
      // Draw arrowhead at start point too
      final reverseAngle = angle + pi;
      final startArrowP1 = Offset(
        start.dx - arrowLength * cos(reverseAngle - arrowAngle),
        start.dy - arrowLength * sin(reverseAngle - arrowAngle),
      );
      final startArrowP2 = Offset(
        start.dx - arrowLength * cos(reverseAngle + arrowAngle),
        start.dy - arrowLength * sin(reverseAngle + arrowAngle),
      );

      final startArrowPath = Path()
        ..moveTo(start.dx, start.dy)
        ..lineTo(startArrowP1.dx, startArrowP1.dy)
        ..moveTo(start.dx, start.dy)
        ..lineTo(startArrowP2.dx, startArrowP2.dy);

      canvas.drawPath(startArrowPath, paint);
    }
  }

  void _drawTwoPointer(Canvas canvas, Offset p1, Offset p2, Paint paint) {
    // Draw line
    canvas.drawLine(p1, p2, paint);

    // Draw measurement markers
    const markerSize = 8.0;
    final markerPaint = Paint()
      ..color = paint.color
      ..style = PaintingStyle.fill;

    canvas.drawCircle(p1, markerSize / 2, markerPaint);
    canvas.drawCircle(p2, markerSize / 2, markerPaint);

    // Draw crosshairs
    _drawCrosshair(canvas, p1, markerSize, paint);
    _drawCrosshair(canvas, p2, markerSize, paint);
  }

  void _drawSinglePointer(Canvas canvas, Offset point, Paint paint) {
    const markerSize = 8.0;
    final markerPaint = Paint()
      ..color = paint.color
      ..style = PaintingStyle.fill;

    canvas.drawCircle(point, markerSize / 2, markerPaint);
    _drawCrosshair(canvas, point, markerSize, paint);
  }

  void _drawCrosshair(Canvas canvas, Offset center, double size, Paint paint) {
    final halfSize = size / 2;
    canvas.drawLine(
      Offset(center.dx - halfSize, center.dy),
      Offset(center.dx + halfSize, center.dy),
      paint,
    );
    canvas.drawLine(
      Offset(center.dx, center.dy - halfSize),
      Offset(center.dx, center.dy + halfSize),
      paint,
    );
  }

  void _drawText(Canvas canvas, Offset position, String text, Color color) {
    final textPainter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: 16,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    );
    textPainter.layout();
    textPainter.paint(canvas, position);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// Annotation tools configuration
class AnnotationTool {
  final IconData icon;
  final String label;
  final AnnotationType type;
  final String description;

  const AnnotationTool(this.icon, this.label, this.type, this.description);
}

final List<AnnotationTool> annotationTools = [
  const AnnotationTool(Icons.pause_circle_outline_rounded, 'Pause', AnnotationType.draw, 'Freeze live preview'),
  const AnnotationTool(Icons.lock_rounded, 'Lock', AnnotationType.draw, 'Lock annotations from editing'),
  const AnnotationTool(Icons.pan_tool_rounded, 'Move', AnnotationType.draw, 'Drag/reposition annotations'),
  const AnnotationTool(Icons.brush_rounded, 'Draw', AnnotationType.draw, 'Freehand drawing'),
  const AnnotationTool(Icons.text_fields, 'Text', AnnotationType.text, 'Text label placement'),
  const AnnotationTool(Icons.straighten_rounded, 'Distance', AnnotationType.twoPointer, 'Two-point distance measurement'),
  const AnnotationTool(Icons.location_on_outlined, 'Point', AnnotationType.singlePointer, 'Single point marker'),
  const AnnotationTool(Icons.crop_square, 'Square', AnnotationType.square, 'Square shape'),
  const AnnotationTool(Icons.circle_outlined, 'Circle', AnnotationType.circle, 'Circle/ellipse shape'),
  const AnnotationTool(Icons.arrow_forward_rounded, 'Arrow', AnnotationType.arrowOneWay, 'One-way directional arrow'),
  const AnnotationTool(Icons.palette_outlined, 'Color', AnnotationType.draw, 'Open color picker'),
  const AnnotationTool(Icons.settings_outlined, 'Calibrate', AnnotationType.draw, 'Open calibration panel'),
  const AnnotationTool(Icons.aspect_ratio_rounded, 'Stamp', AnnotationType.draw, 'Toggle calibration stamp'),
  const AnnotationTool(Icons.undo_rounded, 'Undo', AnnotationType.draw, 'Undo last annotation'),
  const AnnotationTool(Icons.redo_rounded, 'Redo', AnnotationType.draw, 'Redo undone annotation'),
  const AnnotationTool(Icons.clear_rounded, 'Erase', AnnotationType.draw, 'Click to remove annotation'),
  const AnnotationTool(Icons.delete_outline_rounded, 'Clear', AnnotationType.draw, 'Clear all annotations'),
];

// Color palette for annotations
const List<Color> annotationColors = [
  Color(0xFFFF00FF), // Magenta
  Color(0xFFFF0000), // Red
  Color(0xFF00FF00), // Green
  Color(0xFF0000FF), // Blue
  Color(0xFFFFFF00), // Yellow
  Color(0xFF00FFFF), // Cyan
  Color(0xFFFFFFFF), // White
  Color(0xFFFFA500), // Orange
];