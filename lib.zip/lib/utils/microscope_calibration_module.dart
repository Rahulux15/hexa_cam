import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:camera/camera.dart' as cam;
import 'package:image/image.dart' as img;
import 'package:shared_preferences/shared_preferences.dart';

class CalibrationException implements Exception {
  CalibrationException(this.message);
  final String message;

  @override
  String toString() => 'CalibrationException: $message';
}

class CalibrationDetectionResult {
  const CalibrationDetectionResult({
    required this.lineCenters,
    required this.pixelDistance,
    required this.debugWidth,
    required this.debugHeight,
  });

  final List<int> lineCenters;
  final double pixelDistance;
  final int debugWidth;
  final int debugHeight;
}

class MicroscopeCalibrationModule {
  MicroscopeCalibrationModule(this._prefs);

  final SharedPreferences _prefs;
  static const String _storageKey = 'hexacam_calibration_factors_v2';

  Future<Uint8List> calibrationCapture(cam.CameraController controller) async {
    if (!controller.value.isInitialized) {
      throw CalibrationException('Camera is not initialized');
    }
    final xfile = await controller.takePicture();
    final bytes = await xfile.readAsBytes();
    if (bytes.isEmpty) {
      throw CalibrationException('Captured image is empty');
    }
    return bytes;
  }

  CalibrationDetectionResult calibrationDetectLines(Uint8List imageBytes) {
    final image = img.decodeImage(imageBytes);
    if (image == null) {
      throw CalibrationException('Failed to decode calibration image');
    }

    final gray = img.grayscale(image);
    final width = gray.width;
    final height = gray.height;
    if (width < 10 || height < 10) {
      throw CalibrationException('Calibration image is too small');
    }

    final scores = List<double>.filled(width, 0);
    for (var x = 1; x < width - 1; x++) {
      var sum = 0.0;
      for (var y = 0; y < height; y++) {
        final left = gray.getPixel(x - 1, y).r;
        final right = gray.getPixel(x + 1, y).r;
        sum += (right - left).abs();
      }
      scores[x] = sum / height;
    }

    final smooth = _movingAverage(scores, 9);
    final mean = smooth.reduce((a, b) => a + b) / smooth.length;
    final std = math.sqrt(
      smooth.map((v) => (v - mean) * (v - mean)).reduce((a, b) => a + b) /
          smooth.length,
    );
    final threshold = mean + (1.2 * std);

    final peaks = <int>[];
    const minSeparation = 8;
    for (var x = 1; x < width - 1; x++) {
      final current = smooth[x];
      if (current < threshold) continue;
      if (current >= smooth[x - 1] && current >= smooth[x + 1]) {
        if (peaks.isEmpty || x - peaks.last >= minSeparation) {
          peaks.add(x);
        } else if (smooth[x] > smooth[peaks.last]) {
          peaks[peaks.length - 1] = x;
        }
      }
    }

    if (peaks.length < 2) {
      throw CalibrationException(
        'Calibration markings not detected. Ensure micrometer lines are sharp and visible.',
      );
    }

    final sorted = [...peaks]..sort();
    final gaps = <double>[];
    for (var i = 1; i < sorted.length; i++) {
      final gap = (sorted[i] - sorted[i - 1]).toDouble();
      if (gap > 2) gaps.add(gap);
    }
    if (gaps.isEmpty) {
      throw CalibrationException(
        'Detected lines are too close to compute spacing reliably.',
      );
    }

    final pixelDistance = gaps.reduce((a, b) => a + b) / gaps.length;
    return CalibrationDetectionResult(
      lineCenters: sorted,
      pixelDistance: pixelDistance,
      debugWidth: width,
      debugHeight: height,
    );
  }

  double calibrationComputeFactor({
    required double measuredPixelDistance,
    required double knownDistanceInMicrometers,
  }) {
    if (measuredPixelDistance <= 0) {
      throw CalibrationException('Measured pixel distance must be > 0');
    }
    if (knownDistanceInMicrometers <= 0) {
      throw CalibrationException('Known distance must be > 0');
    }
    return knownDistanceInMicrometers / measuredPixelDistance;
  }

  double calibrationApply({
    required double factor,
    required double pixelMeasurement,
    bool area = false,
  }) {
    if (factor <= 0) {
      throw CalibrationException('Calibration factor must be > 0');
    }
    if (pixelMeasurement < 0) {
      throw CalibrationException('Pixel measurement cannot be negative');
    }
    if (area) {
      return pixelMeasurement * factor * factor;
    }
    return pixelMeasurement * factor;
  }

  Future<void> saveCalibration({
    required String magnification,
    required String unit,
    required double knownDistance,
    required double measuredPixelDistance,
    required double calibrationFactor,
  }) async {
    final map = _loadRawMap();
    map[magnification] = {
      'magnification': magnification,
      'unit': unit,
      'referenceLength': knownDistance,
      'measuredPixelDistance': measuredPixelDistance,
      'unitPerPixel': calibrationFactor,
      'pixelsPerUnit': 1 / calibrationFactor,
      'createdAt': DateTime.now().toIso8601String(),
    };
    await _prefs.setString(_storageKey, jsonEncode(map));
  }

  Map<String, dynamic>? getCalibration(String magnification) {
    final map = _loadRawMap();
    return map[magnification] as Map<String, dynamic>?;
  }

  Future<void> clearCalibration(String magnification) async {
    final map = _loadRawMap();
    map.remove(magnification);
    await _prefs.setString(_storageKey, jsonEncode(map));
  }

  Future<double> runCalibration({
    required cam.CameraController controller,
    required String magnification,
    required double knownDistanceInMicrometers,
    String unit = 'μm',
  }) async {
    final bytes = await calibrationCapture(controller);
    final detection = calibrationDetectLines(bytes);
    final factor = calibrationComputeFactor(
      measuredPixelDistance: detection.pixelDistance,
      knownDistanceInMicrometers: knownDistanceInMicrometers,
    );
    await saveCalibration(
      magnification: magnification,
      unit: unit,
      knownDistance: knownDistanceInMicrometers,
      measuredPixelDistance: detection.pixelDistance,
      calibrationFactor: factor,
    );
    return factor;
  }

  List<double> _movingAverage(List<double> input, int window) {
    final result = List<double>.filled(input.length, 0);
    if (window <= 1) return [...input];
    final half = window ~/ 2;
    for (var i = 0; i < input.length; i++) {
      var sum = 0.0;
      var count = 0;
      for (var j = i - half; j <= i + half; j++) {
        if (j < 0 || j >= input.length) continue;
        sum += input[j];
        count++;
      }
      result[i] = count == 0 ? input[i] : sum / count;
    }
    return result;
  }

  Map<String, dynamic> _loadRawMap() {
    final raw = _prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) return <String, dynamic>{};
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return <String, dynamic>{};
    }
  }
}
