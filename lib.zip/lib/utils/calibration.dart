import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../state/providers.dart';

// Calibration data models - Exact from specification

class StoredCalibration {
  final String magnification; // "4X", "10X", etc.
  final String unit; // "μm" or "nm"
  final double unitPerPixel;
  final double pixelsPerUnit;
  final double referenceLength;
  final double measuredPixelDistance;
  final double? unitPerDivision; // optional for microscope divisions
  final DateTime createdAt;

  const StoredCalibration({
    required this.magnification,
    required this.unit,
    required this.unitPerPixel,
    required this.pixelsPerUnit,
    required this.referenceLength,
    required this.measuredPixelDistance,
    this.unitPerDivision,
    required this.createdAt,
  });

  factory StoredCalibration.fromJson(Map<String, dynamic> json) {
    return StoredCalibration(
      magnification: json['magnification'] ?? '',
      unit: json['unit'] ?? 'μm',
      unitPerPixel: (json['unitPerPixel'] ?? 0.0).toDouble(),
      pixelsPerUnit: (json['pixelsPerUnit'] ?? 0.0).toDouble(),
      referenceLength: (json['referenceLength'] ?? 0.0).toDouble(),
      measuredPixelDistance: (json['measuredPixelDistance'] ?? 0.0).toDouble(),
      unitPerDivision: json['unitPerDivision']?.toDouble(),
      createdAt:
          DateTime.parse(json['createdAt'] ?? DateTime.now().toIso8601String()),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'magnification': magnification,
      'unit': unit,
      'unitPerPixel': unitPerPixel,
      'pixelsPerUnit': pixelsPerUnit,
      'referenceLength': referenceLength,
      'measuredPixelDistance': measuredPixelDistance,
      if (unitPerDivision != null) 'unitPerDivision': unitPerDivision,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  StoredCalibration copyWith({
    String? magnification,
    String? unit,
    double? unitPerPixel,
    double? pixelsPerUnit,
    double? referenceLength,
    double? measuredPixelDistance,
    double? unitPerDivision,
  }) {
    return StoredCalibration(
      magnification: magnification ?? this.magnification,
      unit: unit ?? this.unit,
      unitPerPixel: unitPerPixel ?? this.unitPerPixel,
      pixelsPerUnit: pixelsPerUnit ?? this.pixelsPerUnit,
      referenceLength: referenceLength ?? this.referenceLength,
      measuredPixelDistance:
          measuredPixelDistance ?? this.measuredPixelDistance,
      unitPerDivision: unitPerDivision ?? this.unitPerDivision,
      createdAt: createdAt,
    );
  }
}

// Magnification levels - Exact from specification
const List<String> magnificationLevels = [
  '4X',
  '10X',
  '20X',
  '40X',
  '60X',
  '100X'
];

// Measurement result
class MeasurementResult {
  final double value;
  final String unit;
  final String formatted;

  const MeasurementResult(this.value, this.unit, this.formatted);

  @override
  String toString() => formatted;
}

// Calibration provider interface
abstract class CalibrationProvider {
  /// Get calibration for a specific magnification
  StoredCalibration? getCalibrationForMagnification(String magnification);

  /// Set calibration from pixel measurement
  StoredCalibration setCalibrationFromPixels({
    required String magnification,
    required double knownDistance,
    required double measuredPixels,
    double? measuredDivisions,
    required String unit,
  });

  /// Set manual calibration
  StoredCalibration setManualCalibration({
    required String magnification,
    required double unitPerPixel,
    required String unit,
  });

  /// Measure pixels using calibration
  MeasurementResult? measurePixels({
    required String magnification,
    required double pixels,
    required String unit,
  });

  /// Measure using microscope divisions
  MeasurementResult? measureDivisions({
    required String magnification,
    required double observedDivisions,
  });

  /// Clear calibration for magnification
  void clearCalibration(String magnification);

  /// Get all calibrations
  Map<String, StoredCalibration> getAllCalibrations();
}

// Default implementation using SharedPreferences
class SharedPreferencesCalibrationProvider implements CalibrationProvider {
  static const String _storageKey = 'hexacam_calibrations';

  SharedPreferencesCalibrationProvider(Future<SharedPreferences> prefsFuture);

  @override
  StoredCalibration? getCalibrationForMagnification(String magnification) {
    // Implementation will be added when we integrate with Riverpod
    return null;
  }

  @override
  StoredCalibration setCalibrationFromPixels({
    required String magnification,
    required double knownDistance,
    required double measuredPixels,
    double? measuredDivisions,
    required String unit,
  }) {
    final unitPerPixel = knownDistance / measuredPixels;
    final pixelsPerUnit = measuredPixels / knownDistance;
    final unitPerDivision =
        measuredDivisions != null ? knownDistance / measuredDivisions : null;

    return StoredCalibration(
      magnification: magnification,
      unit: unit,
      unitPerPixel: unitPerPixel,
      pixelsPerUnit: pixelsPerUnit,
      referenceLength: knownDistance,
      measuredPixelDistance: measuredPixels,
      unitPerDivision: unitPerDivision,
      createdAt: DateTime.now(),
    );
  }

  @override
  StoredCalibration setManualCalibration({
    required String magnification,
    required double unitPerPixel,
    required String unit,
  }) {
    return StoredCalibration(
      magnification: magnification,
      unit: unit,
      unitPerPixel: unitPerPixel,
      pixelsPerUnit: 1 / unitPerPixel,
      referenceLength: 0,
      measuredPixelDistance: 0,
      createdAt: DateTime.now(),
    );
  }

  @override
  MeasurementResult? measurePixels({
    required String magnification,
    required double pixels,
    required String unit,
  }) {
    final calibration = getCalibrationForMagnification(magnification);
    if (calibration == null) return null;

    final value = pixels * calibration.unitPerPixel;
    final convertedValue = unit == calibration.unit
        ? value
        : _convertUnits(value, calibration.unit, unit);
    final formatted = '${convertedValue.toStringAsFixed(2)} $unit';

    return MeasurementResult(convertedValue, unit, formatted);
  }

  @override
  MeasurementResult? measureDivisions({
    required String magnification,
    required double observedDivisions,
  }) {
    final calibration = getCalibrationForMagnification(magnification);
    if (calibration == null || calibration.unitPerDivision == null) return null;

    final value = observedDivisions * calibration.unitPerDivision!;
    final formatted = '${value.toStringAsFixed(2)} ${calibration.unit}';

    return MeasurementResult(value, calibration.unit, formatted);
  }

  @override
  void clearCalibration(String magnification) {
    // Implementation will be added when we integrate with Riverpod
  }

  @override
  Map<String, StoredCalibration> getAllCalibrations() {
    // Implementation will be added when we integrate with Riverpod
    return {};
  }

  // Unit conversion helper
  double _convertUnits(double value, String fromUnit, String toUnit) {
    if (fromUnit == toUnit) return value;

    // μm to nm: multiply by 1000
    // nm to μm: divide by 1000
    if ((fromUnit == 'μm' && toUnit == 'nm') ||
        (fromUnit == 'nm' && toUnit == 'μm')) {
      return fromUnit == 'μm' ? value * 1000 : value / 1000;
    }

    // mm conversions
    if (fromUnit == 'mm' && toUnit == 'μm') return value * 1000;
    if (fromUnit == 'μm' && toUnit == 'mm') return value / 1000;
    if (fromUnit == 'mm' && toUnit == 'nm') return value * 1000000;
    if (fromUnit == 'nm' && toUnit == 'mm') return value / 1000000;

    return value; // No conversion available
  }
}

// Riverpod provider for calibration
final calibrationProvider =
    StateNotifierProvider<CalibrationNotifier, Map<String, StoredCalibration>>(
        (ref) {
  return CalibrationNotifier(ref.watch(sharedPreferencesProvider));
});

class CalibrationNotifier
    extends StateNotifier<Map<String, StoredCalibration>> {
  final SharedPreferences _prefs;

  CalibrationNotifier(this._prefs) : super({}) {
    _loadCalibrations();
  }

  void _loadCalibrations() {
    final raw =
        _prefs.getString(SharedPreferencesCalibrationProvider._storageKey);
    if (raw == null) return;

    try {
      final map = Map<String, dynamic>.from(Uri.splitQueryString(raw));
      state = map.map((k, v) => MapEntry(
          k,
          StoredCalibration.fromJson(
              Map<String, dynamic>.from(Uri.splitQueryString(v)))));
    } catch (e) {
      debugPrint('Error loading calibrations: $e');
    }
  }

  void _saveCalibrations() {
    try {
      final map = state.map((k, v) => MapEntry(k, v.toJson()));
      final encoded = map.toString();
      _prefs.setString(
          SharedPreferencesCalibrationProvider._storageKey, encoded);
    } catch (e) {
      debugPrint('Error saving calibrations: $e');
    }
  }

  StoredCalibration? getCalibrationForMagnification(String magnification) {
    return state[magnification];
  }

  void setCalibration(StoredCalibration calibration) {
    state = {...state, calibration.magnification: calibration};
    _saveCalibrations();
  }

  void clearCalibration(String magnification) {
    state = {...state}..remove(magnification);
    _saveCalibrations();
  }

  Map<String, StoredCalibration> getAllCalibrations() {
    return Map.unmodifiable(state);
  }
}

// Basic Annotation class for measurement calculations
class Annotation {
  final String id;
  final String type;
  final List<Offset> points;
  final String? text;
  final Color color;
  final double strokeWidth;
  final String timestamp;
  final String? measurement;

  const Annotation({
    required this.id,
    required this.type,
    required this.points,
    this.text,
    required this.color,
    this.strokeWidth = 3.0,
    required this.timestamp,
    this.measurement,
  });
}

// Measurement helper functions
class MeasurementCalculator {
  static String getMeasurementText(Annotation annotation) {
    return annotation.measurement ?? '';
  }
}
