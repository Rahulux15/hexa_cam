import 'dart:math';
import 'dart:ui';
import '../data/models/point.dart';

class AnnotationGeometry {
  static List<HexaPoint> toSourceSpace(List<HexaPoint> points, Size sourceSize, Size displaySize) {
    return points.map((p) => HexaPoint(x: (p.x / displaySize.width) * sourceSize.width, y: (p.y / displaySize.height) * sourceSize.height)).toList();
  }

  static List<HexaPoint> toDisplaySpace(List<HexaPoint> points, Size sourceSize, Size displaySize) {
    return points.map((p) => HexaPoint(x: (p.x / sourceSize.width) * displaySize.width, y: (p.y / sourceSize.height) * displaySize.height)).toList();
  }

  static Rect getBoundingBox(List<HexaPoint> points) {
    if (points.isEmpty) return Rect.zero;
    final xs = points.map((p) => p.x); final ys = points.map((p) => p.y);
    return Rect.fromLTRB(xs.reduce((a, b) => a < b ? a : b), ys.reduce((a, b) => a < b ? a : b), xs.reduce((a, b) => a > b ? a : b), ys.reduce((a, b) => a > b ? a : b));
  }

  static double distance(HexaPoint a, HexaPoint b) {
    final dx = b.x - a.x; final dy = b.y - a.y;
    return sqrt(dx * dx + dy * dy);
  }
}
