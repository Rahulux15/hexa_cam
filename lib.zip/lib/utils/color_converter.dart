import 'package:flutter/material.dart';

class ColorConverter {
  static String colorToHex(Color color) => '#${color.toARGB32().toRadixString(16).padLeft(8, '0').substring(2).toUpperCase()}';

  static Color hexToColor(String hex) {
    hex = hex.replaceAll('#', '');
    if (hex.length == 6) hex = 'FF$hex';
    return Color(int.parse(hex, radix: 16));
  }

  static Color hsvToColor(double hue, double saturation, double brightness) {
    final hsv = HSVColor.fromAHSV(1.0, hue.clamp(0, 360), saturation.clamp(0, 1), brightness.clamp(0, 1));
    return hsv.toColor();
  }

  static HSVColor colorToHsv(Color color) => HSVColor.fromColor(color);
}
