import '../data/models/annotation.dart';
import '../data/models/point.dart';
import 'annotation_geometry.dart';

class AnnotationDedup {
  static const double _pointTolerance = 6.0;

  static List<Annotation> dedupe(List<Annotation> annotations) {
    final deduped = <Annotation>[];
    for (final ann in annotations) {
      final idx = deduped.indexWhere((e) => _areEquivalent(e, ann));
      if (idx == -1) { deduped.add(ann); }
      else {
        final existing = deduped[idx];
        deduped[idx] = _score(ann.measurement) >= _score(existing.measurement) ? ann : existing;
      }
    }
    return deduped;
  }

  static bool _areEquivalent(Annotation a, Annotation b) {
    if (a.type != b.type || a.color.toARGB32() != b.color.toARGB32()) return false;
    if ((a.text ?? '') != (b.text ?? '')) return false;
    return _pointsEquivalent(a.points, b.points) || _boundsEquivalent(a.points, b.points);
  }

  static bool _pointsEquivalent(List<HexaPoint> a, List<HexaPoint> b) {
    if (a.length != b.length) return false;
    for (int i = 0; i < a.length; i++) {
      if ((a[i].x - b[i].x).abs() > _pointTolerance || (a[i].y - b[i].y).abs() > _pointTolerance) return false;
    }
    return true;
  }

  static bool _boundsEquivalent(List<HexaPoint> a, List<HexaPoint> b) {
    final ba = AnnotationGeometry.getBoundingBox(a); final bb = AnnotationGeometry.getBoundingBox(b);
    final tol = (_pointTolerance).clamp(0, ba.width * 0.08).clamp(0, bb.width * 0.08);
    return (ba.left - bb.left).abs() <= tol && (ba.top - bb.top).abs() <= tol && (ba.right - bb.right).abs() <= tol && (ba.bottom - bb.bottom).abs() <= tol;
  }

  static int _score(String? m) {
    if (m == null) return 0;
    if (RegExp(r'(?:μm|nm)').hasMatch(m)) return 3;
    if (m.contains('px')) return 1;
    return 2;
  }
}
