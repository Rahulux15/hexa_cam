import 'dart:io';
import 'dart:typed_data';

import 'package:gal/gal.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

class FileService {
  static const _uuid = Uuid();

  static String generateAssetId([String prefix = 'media']) =>
      '$prefix-${_uuid.v4()}';

  static Future<void> saveToDevice(Uint8List bytes, String filename) async {
    final sanitized =
        filename.replaceAll(RegExp(r'[<>:"/\\|?*\x00-\x1F]'), '-').trim();
    final name = sanitized.isEmpty
        ? 'hexacam-${DateTime.now().millisecondsSinceEpoch}'
        : sanitized;
    await Gal.putImageBytes(bytes, name: name);
  }

  static Future<void> saveVideoToDevice(
      String videoPath, String filename) async {
    await Gal.putVideo(videoPath);
  }

  static Future<String> getTempPath() async {
    final dir = await getTemporaryDirectory();
    return dir.path;
  }

  static Future<String> persistCapture({
    required String sourcePath,
    required String filename,
    required String folderName,
  }) async {
    final docs = await getApplicationDocumentsDirectory();
    final mediaDir = Directory(p.join(docs.path, 'captures', folderName));
    if (!await mediaDir.exists()) {
      await mediaDir.create(recursive: true);
    }

    final safeName =
        _safeFilename(filename, fallbackExtension: p.extension(sourcePath));
    final destination = p.join(mediaDir.path, safeName);
    final file = await File(sourcePath).copy(destination);
    return file.path;
  }

  static Future<String> persistBytes({
    required Uint8List bytes,
    required String filename,
    required String folderName,
    String subdirectory = 'reports',
  }) async {
    final docs = await getApplicationDocumentsDirectory();
    final mediaDir = Directory(p.join(docs.path, subdirectory, folderName));
    if (!await mediaDir.exists()) {
      await mediaDir.create(recursive: true);
    }

    final safeName = _safeFilename(filename);
    final destination = p.join(mediaDir.path, safeName);
    final file = File(destination);
    await file.writeAsBytes(bytes, flush: true);
    return file.path;
  }

  static Future<Uint8List> readBytes(String path) async {
    return File(path).readAsBytes();
  }

  static String _safeFilename(String value, {String fallbackExtension = ''}) {
    final cleaned =
        value.replaceAll(RegExp(r'[<>:"/\\|?*\x00-\x1F]'), '-').trim();
    if (cleaned.isEmpty) {
      final extension = fallbackExtension.isEmpty ? '' : fallbackExtension;
      return 'hexacam-${DateTime.now().millisecondsSinceEpoch}$extension';
    }
    if (p.extension(cleaned).isEmpty && fallbackExtension.isNotEmpty) {
      return '$cleaned$fallbackExtension';
    }
    return cleaned;
  }
}
