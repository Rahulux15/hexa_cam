import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  final SharedPreferences _prefs;
  StorageService(this._prefs);

  T? get<T>(String key) {
    final raw = _prefs.getString(key);
    if (raw == null) {
      if (key == 'folders') {
        final backup = _prefs.getString('${key}_backup');
        if (backup != null) {
          try {
            return jsonDecode(backup) as T;
          } catch (_) {}
        }
      }
      return null;
    }
    try { return jsonDecode(raw) as T; } catch (e) { _prefs.remove(key); return null; }
  }

  Future<void> set<T>(String key, T value) async {
    if (key == 'folders' && value is List) value = _sanitizeFolders(value) as T;
    final encoded = jsonEncode(value);
    await _prefs.setString(key, encoded);
    if (key == 'folders') {
      await _prefs.setString('${key}_backup', encoded);
    }
  }

  List<dynamic> _sanitizeFolders(List<dynamic> folders) {
    return folders.map((folder) {
      if (folder['images'] == null) return folder;
      final images = (folder['images'] as List).map((image) {
        final img = Map<String, dynamic>.from(image);
        if (img['mediaId'] != null && (img['imageUrl'] as String?)?.startsWith('data:') == true) img['imageUrl'] = '';
        if ((img['thumbnail'] as String?)?.startsWith('data:') == true && img['type'] != 'video' && (img['thumbnailId'] != null || img['mediaId'] != null)) img['thumbnail'] = '';
        return img;
      }).toList();
      return {...folder, 'images': images};
    }).toList();
  }

  Future<void> remove(String key) async => await _prefs.remove(key);
  Future<void> clear() async => await _prefs.clear();
}
